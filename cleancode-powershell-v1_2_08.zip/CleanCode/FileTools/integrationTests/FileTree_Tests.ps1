
Set-StrictMode -Version Latest
Import-Module CleanCode\Assertion
Import-Module CleanCode\FileTools -Force

$myTestDir = "filetree-test-dir"
function Go-Home()
{
	$homeDir = Join-Path $env:TEMP $myTestDir
	if (! (Test-Path $homeDir)) { 
		new-item -path $env:TEMP -name $myTestDir -type directory -Force | Out-Null
	}
	cd $homeDir
}


Go-Home

# using here-string argument
$result = New-FileTree @"
foo\bar\abc.txt
foo\bar\def.txt
foo\gollum\stuff1.txt

foo\other dir\
foo/other2/
#foo/commented-out/
"@

$actualTree = ls -Recurse | % { $_.fullname }
$actualTree
Assert-Expression $result.Count 5
Assert-Expression $actualTree.Count 8

# Using list argument
$result = New-FileTree foo\list\l1.txt,foo\list\l2.txt,foo\list\otherlist\
$actualTree = ls foo/list -Recurse | % { $_.fullname }
$actualTree
Assert-Expression $result.Count 3
Assert-Expression $actualTree.Count 3

cd ..

rmdir $myTestDir -Recurse -Force

Get-AssertCounts
