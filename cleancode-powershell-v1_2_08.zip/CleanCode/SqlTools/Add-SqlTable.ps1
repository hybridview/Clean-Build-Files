##########################################################################
# Source: http://gallery.technet.microsoft.com/scriptcenter/c193ed1a-9152-4bda-b5c0-acd044e68b2c
# (obsoletes the version at http://poshcode.org/3295)
# Author: Chad Miller
# Date:   2012.07.20
# ** Includes modification by msorens
##########################################################################

Set-StrictMode -Version Latest

try {add-type -AssemblyName "Microsoft.SqlServer.ConnectionInfo, Version=10.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91" -EA Stop} 
catch {add-type -AssemblyName "Microsoft.SqlServer.ConnectionInfo"} 
 
try {add-type -AssemblyName "Microsoft.SqlServer.Smo, Version=10.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91" -EA Stop}  
catch {add-type -AssemblyName "Microsoft.SqlServer.Smo"}  
 

#######################  
<#  
.SYNOPSIS
Creates a SQL Server table from a DataTable.

.DESCRIPTION
Creates a SQL Server table from a DataTable using SMO. (Based on Chad Miller's original work--see Links section.)

.PARAMETER ServerInstance
Character string or SMO server object specifying the name of an instance of
the Database Engine. For default instances, only specify the computer name:
"MyComputer". For named instances, use the format "ComputerName\InstanceName".
If -ServerInstance is not specified Add-SqlTable attempts to infer it:
* If on a SQLSERVER: drive (or alias) and the path specifies the SQL folder,
Add-SqlTable uses the server and instance specified in the path.
* If not on a SQLSERVER: drive but the current location on your SQLSERVER:
drive specifies the SQL folder, Add-SqlTable uses the server and instance
specified in that path.

.PARAMETER Database
A character string specifying the name of a database. Add-SqlTable connects to
this database in the instance specified by -ServerInstance.
If -Database is not specified Add-SqlTable attempts to infer it:
* If on a SQLSERVER: drive (or alias) and the path specifies both the SQL folder
and a database name, Add-SqlTable uses the database specified in the path.
* If not on a SQLSERVER: drive but the current location on your SQLSERVER:
drive specifies both the SQL folder and a database name, Add-SqlTable uses
the database specified in that path.

.PARAMETER TableName
Name of the table to create on the SQL Server instance.

.PARAMETER DataTable
A System.Data.DataTable from which the SQL table's schema is derived:
the names and data types of the columns in the DataTable are used
to define the SQL table.

.PARAMETER Username
Specifies the login ID for making a SQL Server Authentication connection
to an instance of the Database Engine. The password must be specified
using -Password. If -Username and -Password are not specified, Add-SqlTable
attempts a Windows Authentication connection using the Windows account running
the PowerShell session.  When possible, use Windows Authentication.  

.PARAMETER Password
Specifies the password for the SQL Server Authentication login ID specified
in -Username. Passwords are case-sensitive.
When possible, use Windows Authentication.
SECURITY NOTE: If you type -Password followed by your password, the password
is visible to anyone who can see your monitor. If you use -Password in
a .ps1 script, anyone reading the script file will see your password.
Assign appropriate permissions to the file to allow only authorized users
to read the file.

.PARAMETER MaxLength
Capacity for VarChar and VarBinary columns (limited to 8000 maximum).
Any data longer than this defined value will be truncated when inserted.

.PARAMETER RowId
Serving as both a switch and a column name, specifying -RowId adds
an identity column to the table with the value supplied as the column name.

.PARAMETER AsScript
If enabled, Add-SqlTable generates a script to create a table
without actually creating it.

.PARAMETER DropExisting
If enabled, Add-SqlTable will check whether the table exists before
attempting to create it. If it does exist, it is first dropped.
Attempting to use Add-SqlTable without this switch when the table already
exists generates an error.

.INPUTS
None. You cannot pipe objects to Add-SqlTable.

.OUTPUTS
None.

.EXAMPLE  
$dt = Invoke-Sqlcmd -ServerInstance "Z003\R2" -Database pubs "select *  from authors"; Add-SqlTable -ServerInstance "Z003\R2" -Database pubscopy -TableName authors -DataTable $dt  
This example loads a variable dt of type DataTable from a query and creates an empty SQL Server table.

.EXAMPLE  
$dt = Get-Alias | Out-DataTable; Add-SqlTable -ServerInstance "Z003\R2" -Database pubscopy -TableName alias -DataTable $dt  
This example creates a DataTable from the properties of Get-Alias and creates an empty SQL Server table.  

.NOTES  
Add-SqlTable uses SQL Server Management Objects (SMO).
SMO is installed with SQL Server Management Studio and is available  
as a separate download:
http://www.microsoft.com/downloads/details.aspx?displaylang=en&FamilyID=ceb4346f-657f-4d28-83f5-aae0c5c83d52  
Version History  
v1.0   - Chad Miller - Initial Release  
v1.1   - Chad Miller - Updated documentation 
v1.2   - Chad Miller - Add loading Microsoft.SqlServer.ConnectionInfo 
v1.3   - Chad Miller - Added error handling 
v1.4   - Chad Miller - Add VarCharMax and VarBinaryMax handling 
v1.5   - Chad Miller - Added AsScript switch to output script instead of creating table 
v1.6   - Chad Miller - Updated Get-SqlType types 

.LINK
[Add-SqlTable original by Chad Miller](http://gallery.technet.microsoft.com/scriptcenter/c193ed1a-9152-4bda-b5c0-acd044e68b2c)
.LINK
Out-DataTable
.LINK
Write-DataTable
.LINK
Out-SqlTable
.LINK
Update-DBEnvironment

#>  
function Add-SqlTable  
{  
  
    [CmdletBinding()]  
    param(  
    [Parameter(Position=0, Mandatory=$false)] [string]$ServerInstance,  
    [Parameter(Position=1, Mandatory=$false)] [string]$Database,  
    [Parameter(Position=2, Mandatory=$true)] [String]$TableName,  
    [Parameter(Position=3, Mandatory=$true)] [System.Data.DataTable]$DataTable,  
    [Parameter(Position=4, Mandatory=$false)] [string]$Username,  
    [Parameter(Position=5, Mandatory=$false)] [string]$Password,  
    [ValidateRange(0,8000)]  
    [Parameter(Position=6, Mandatory=$false)] [Int32]$MaxLength=1000, 
    [Parameter(Position=7, Mandatory=$false)] [string]$RowId,  
    [Parameter(Position=8, Mandatory=$false)] [switch]$AsScript,
    [Parameter(Position=9, Mandatory=$false)] [switch]$DropExisting
    )  
 
 # 2012.10.19 msorens: Allow ServerInstance or Database to be inferred
Update-DBEnvironment ([ref]$ServerInstance) ([ref]$Database)
 
try { 
    if($Username)  
    { $con = new-object ("Microsoft.SqlServer.Management.Common.ServerConnection") $ServerInstance,$Username,$Password }  
    else  
    { $con = new-object ("Microsoft.SqlServer.Management.Common.ServerConnection") $ServerInstance }  
      
    $con.Connect()  
  
  	if ($DropExisting) { 
		$params = @{}
		if ($UserName) { $params["UserName"] = $Username }
		if ($Password) { $params["Password"] = $Password }
		$dropQuery = "IF OBJECT_ID('{0}') IS NOT NULL DROP TABLE {0}" -f $TableName
		Invoke-Sqlcmd -Server $ServerInstance -Database $Database @params `
			-Query $dropQuery -SuppressProviderContextWarning
	}

    $server = new-object ("Microsoft.SqlServer.Management.Smo.Server") $con  
    $db = $server.Databases[$Database]  
    $table = new-object ("Microsoft.SqlServer.Management.Smo.Table") $db, $TableName  
	
	if ($RowId) {
		$dataType = new-object ("Microsoft.SqlServer.Management.Smo.DataType") "Int"
	    $col = new-object ("Microsoft.SqlServer.Management.Smo.Column") $table, $RowId, $dataType  
        $col.Nullable = $false  
		$col.Identity = $true
        $table.Columns.Add($col)  

	}
	
    foreach ($column in $DataTable.Columns)  
    {  
        $sqlDbType = [Microsoft.SqlServer.Management.Smo.SqlDataType]"$(Get-SqlType $column.DataType.Name)"  
        if ($sqlDbType -eq 'VarBinary' -or $sqlDbType -eq 'VarChar')  
        {  
            if ($MaxLength -gt 0)  
            {$dataType = new-object ("Microsoft.SqlServer.Management.Smo.DataType") $sqlDbType, $MaxLength} 
            else 
            { $sqlDbType  = [Microsoft.SqlServer.Management.Smo.SqlDataType]"$(Get-SqlType $column.DataType.Name)Max" 
              $dataType = new-object ("Microsoft.SqlServer.Management.Smo.DataType") $sqlDbType 
            } 
        }  
        else  
        { $dataType = new-object ("Microsoft.SqlServer.Management.Smo.DataType") $sqlDbType }  
        $col = new-object ("Microsoft.SqlServer.Management.Smo.Column") $table, $column.ColumnName, $dataType  
        $col.Nullable = $column.AllowDBNull
        $table.Columns.Add($col)  
    }  
  
    if ($AsScript) { 
        $table.Script() 
    } 
    else { 
        $table.Create() 
    } 
} 
catch { 
    $message = $_.Exception.GetBaseException().Message 
    Write-Error $message 
} 
   
} #Add-SqlTable

#######################  
function Get-SqlType  
{  
    param([string]$TypeName)  
  
    switch ($TypeName)   
    {  
        'Boolean' {[Data.SqlDbType]::Bit}  
        'Byte[]' {[Data.SqlDbType]::VarBinary}  
        'Byte'  {[Data.SQLDbType]::VarBinary}  
        'Datetime'  {[Data.SQLDbType]::DateTime}  
        'Decimal' {[Data.SqlDbType]::Decimal}  
        'Double' {[Data.SqlDbType]::Float}  
        'Guid' {[Data.SqlDbType]::UniqueIdentifier}  
        'Int16'  {[Data.SQLDbType]::SmallInt}  
        'Int32'  {[Data.SQLDbType]::Int}  
        'Int64' {[Data.SqlDbType]::BigInt}  
        'UInt16'  {[Data.SQLDbType]::SmallInt}  
        'UInt32'  {[Data.SQLDbType]::Int}  
        'UInt64' {[Data.SqlDbType]::BigInt}  
        'Single' {[Data.SqlDbType]::Decimal} 
        default {[Data.SqlDbType]::VarChar}  
    }  
      
} #Get-SqlType 

Export-ModuleMember Add-SqlTable
