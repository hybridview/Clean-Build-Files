
$srcModule = $MyInvocation.MyCommand.Path -replace '\\tests\\.*', ''
Import-Module -force $srcModule
Set-StrictMode -Version Latest

InModuleScope FileTools {

$helperDir = "$PSScriptRoot\TestHelpers"
Resolve-Path $helperDir\*.ps1 | % { . $_.ProviderPath }

Describe "ConvertFrom-Text" {

$multiLineTextArray = @'
DC Options: IS_GC
'@,
@'
DC=company,DC=org
    BLL\012ADDC001 via RPC
        DC object GUID: 26446473-3433-4c73-942d-c750f0e476ec
        Last attempt @ 2007-08-21 13:38:53 was successful.
'@,
@'
CN=Configuration,DC=company,DC=org
    BLL\045ADDC001 via RPC
        DC object GUID: 26446473-3433-4c73-942d-c750f0e476ec
        Last attempt @ 2007-08-21 13:38:53 was successful.
'@,
@'
CN=Schema,CN=Configuration,DC=company,DC=org
    BLL\067ADDC001 via RPC
        DC object GUID: 26446473-3433-4c73-942d-c750f0e476ec
        Last attempt @ 2007-08-21 13:38:54 was successful.
'@

$multiLineRegex = [regex] '(?msx)
    ^ (?<partition> (CN|DC)=[^$]+?)\s*$
    .+? # skip intervening
    (?<Site> \w+) \\ (?<DC> \w+)
    .+?
    Last\ attempt\D+ (?<date> [\d\-]+\ [\d\:]+ )
'

	Context "Fixed-width data from a pipe" {
$text = @"
12345671234567890123
george jetson    5  
warren buffett   123
horatioalger     -99
"@
		$idValues = '123','5  ','123','-99'
		$regex = "^(?<FirstName>.{7})(?<LastName>.{10})(?<Id>.{3})$"
		$data = $text -split "`r`n" | ConvertFrom-Text -pattern $regex

		It "Produces correct row count" {
			$data.Count | Should be 4
		}
		It "Produces correct property count" {
		    (gm �input $data[0] -MemberType NoteProperty).Count | Should be 3
		}
		It "Produces correct property names" {
    		(gm �input $data[0] -MemberType NoteProperty | % { $_.Name } | Sort) |
				Should be 'FirstName','Id','LastName'
		}
		It "Produces correct Id property" {
    		$data | % { $_.Id} | Should Be $idValues
		}
	}

	Context "Fixed-width data passed in as a parameter" {
$text = @"
12345671234567890123
george jetson    5  
warren buffett   123
horatioalger     -99
"@
		$nameValues = '1234567890','jetson    ','buffett   ','alger     '
		$regex = "^(?<FirstName>.{7})(?<LastName>.{10})(?<Id>.{3})$"
		$data = ConvertFrom-Text -InputObject ($text -split "`r`n") -pattern $regex

		It "Produces correct row count" {
			$data.Count | Should be 4
		}
		It "Produces correct property count" {
		    (gm �input $data[0] -MemberType NoteProperty).Count | Should be 3
		}
		It "Produces correct property names" {
    		(gm �input $data[0] -MemberType NoteProperty | % { $_.Name } | Sort) |
				Should be 'FirstName','Id','LastName'
		}
		It "Produces correct LastName property" {
    		$data | % { $_.LastName} | Should Be $nameValues
		}
	}

	Context "Fixed-width data with no anchors can grab partial lines" {
$text = @"
12345671234567890123
george jetson    arbitrary text here
warren buffett   stuff
horatioalger     more stuff
"@
		$idValues = '123','arb','stu','mor'
		$regex = "(?<FirstName>.{7})(?<LastName>.{10})(?<Id>.{3})" # no anchors
		$data = $text -split "`r`n" | ConvertFrom-Text -pattern $regex -RequireAll

		It "Produces correct field names" {
    		(gm �input $data[0] -MemberType NoteProperty | % { $_.Name } | Sort) |
				Should be @('FirstName','Id','LastName')
		}
		It "Produces correct Id property" {
    		$data | % { $_.Id} | Should Be $idValues
		}
	}

	Context "Fixed-width/ragged-right data includes varying last property length" {
$text = @"
12345671234567890123
george jetson    arbitrary text here
warren buffett   stuff
horatioalger     more stuff
"@
		$descriptionValues = '123','arbitrary text here','stuff','more stuff'
		$regex = "(?<FirstName>.{7})(?<LastName>.{10})(?<Description>.*)" # ragged right
		$data = $text -split "`r`n" | ConvertFrom-Text -pattern $regex

		It "Produces correct field names" {
    		(gm �input $data[0] -MemberType NoteProperty | % { $_.Name } | Sort) |
				Should be @('FirstName','Description','LastName')
		}
		It "Produces correct Description property" {
    		$data | % { $_.Description} | Should Be $descriptionValues
		}
	}

	Context "Variable-width" {
$text = @'
127.0.0.1 - frank [10/Oct/2012:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326
111.111.111.111 - martha [18/Oct/2012:01:17:44 -0700] "GET / HTTP/1.0" 200 101
111.111.111.111 - - [18/Oct/2007:11:17:55 -0700] "GET /style.css HTTP/1.1" 200 4525
'@
		$apacheExtractor =
			'(?<Host>\S*)',
			'(?<LogName>.*?)',
			'(?<UserId>\S*)',
			'\[(?<TimeStamp>.*?)\]',
			'"(?<Request>[^"]*)"',
			'(?<Status>\d{3})',
			'(?<BytesSent>\S*)' -join '\s+'

		$data = $text -split "`r`n" | ConvertFrom-Text -Pattern "^$apacheExtractor$"

		It "Produces correct row count" {
			$data.Count | Should be 3
		}
		It "Produces correct property count" {
		    (gm �input $data[0] -MemberType NoteProperty).Count | Should be 7
		}
		It "Produces correct property names" {
    		(gm �input $data[0] -MemberType NoteProperty | % { $_.Name } | Sort) |
				Should be 'BytesSent','Host','LogName','Request','Status','TimeStamp','UserId'
		}
		It "Produces correct properties" {
    		$data | % { $_.UserId} | Should Be 'frank','martha','-'
    		$data | % { $_.BytesSent} | Should Be 2326,101,4525
    		$data[1].TimeStamp | Should Be '18/Oct/2012:01:17:44 -0700'
		}
	}

	Context "Multiple-line from single string" {
		$data = $multiLineTextArray | Out-String |
			ConvertFrom-Text -pattern $multiLineRegex -Multiline

		It "Produces correct row count" {
			$data.Count | Should be 3
		}
		It "Produces correct property count" {
		    (gm �input $data[0] -MemberType NoteProperty).Count | Should be 4
		}
		It "Produces correct property names" {
    		(gm �input $data[0] -MemberType NoteProperty | % { $_.Name } | Sort) |
				Should be 'date','DC','partition','Site'
		}
		It "Produces correct properties" {
    		$data[0].partition | Should Be 'DC=company,DC=org'
    		$data[1].partition | Should Be 'CN=Configuration,DC=company,DC=org'
    		$data[1].site | Should Be 'BLL'
    		$data[1].dc | Should Be '045ADDC001'
    		$data[2].site | Should Be 'BLL'
    		$data[2].dc | Should Be '067ADDC001'
		}
	}

	Context "Multiple-line from array" {
		$data = $multiLineTextArray | 
			ConvertFrom-Text -pattern $multiLineRegex -Multiline

		It "Produces correct row count" {
			$data.Count | Should be 3
		}
		It "Produces correct property count" {
		    (gm �input $data[0] -MemberType NoteProperty).Count | Should be 4
		}
		It "Produces correct property names" {
    		(gm �input $data[0] -MemberType NoteProperty | % { $_.Name } | Sort) |
				Should be 'date','DC','partition','Site'
		}
		It "Produces correct properties" {
    		$data[0].partition | Should Be 'DC=company,DC=org'
    		$data[1].partition | Should Be 'CN=Configuration,DC=company,DC=org'
    		$data[1].site | Should Be 'BLL'
    		$data[1].dc | Should Be '045ADDC001'
    		$data[2].site | Should Be 'BLL'
    		$data[2].dc | Should Be '067ADDC001'
		}
	}

	Context "Multiple-line with passed parameter" {
		$data = ConvertFrom-Text -InputObject $multiLineTextArray `
				-pattern $multiLineRegex -Multiline
		It "Produces correct row count" {
			$data.Count | Should be 3
		}
		It "Produces correct property count" {
		    (gm �input $data[0] -MemberType NoteProperty).Count | Should be 4
		}
		It "Produces correct property names" {
    		(gm �input $data[0] -MemberType NoteProperty | % { $_.Name } | Sort) |
				Should be 'date','DC','partition','Site'
		}
		It "Produces correct properties" {
    		$data[0].partition | Should Be 'DC=company,DC=org'
    		$data[1].partition | Should Be 'CN=Configuration,DC=company,DC=org'
    		$data[1].site | Should Be 'BLL'
    		$data[1].dc | Should Be '045ADDC001'
    		$data[2].site | Should Be 'BLL'
    		$data[2].dc | Should Be '067ADDC001'
		}
	}
}
}
