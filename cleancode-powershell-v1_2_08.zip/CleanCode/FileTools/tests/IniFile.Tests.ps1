$srcModule = $MyInvocation.MyCommand.Path -replace '\\tests\\.*', ''
Import-Module -force $srcModule

InModuleScope FileTools {

$helperDir = "$PSScriptRoot\TestHelpers"
Resolve-Path $helperDir\*.ps1 | % { . $_.ProviderPath }

function LoadTestDataToFile($data, $file)
{
	$data | Set-Content $file
	return (Get-IniFile $file)
}

Describe "Get-IniFile" {

$dataWithoutSection = @"
foo=1
bar=stuff
"@

$dataWithOneSection = @"
[config]
color=green
size=0.5
265=true
"@

$dataWithMultipleSections = @"
foo=1
[config]
color=green
[sizes]
a=0.5
265=true
"@

$dataWithSameKeyInDifferentSections = @"
[configA]
color=green
[configB]
color=red
"@

$dataWithRepeatedSections = @"
[config]
color=green
[other]
foo=bar
[config]
size=42
"@

$dataWithMultipleValues = @"
[commands]
twocmd=command2a
twocmd=command2b
onecmd=command1
fourcmd=command4a
fourcmd=command4b
fourcmd=command4c
fourcmd=command4d
"@

$dataForFileOne = @"
isolatedSettingOne=foo
[config]
color=green
[param]
sameKey=foobar
[commands]
cmd=commandA
cmd=commandD
[soloFile1]
a=1
"@
$dataForFileTwo = @"
isolatedSettingTwo=bar
[config]
size=25
[commands]
cmd=commandC
cmd=commandB
[param]
sameKey=542
[soloFile2]
b=2
"@

	BeforeEach {
		$testFile = [System.IO.Path]::GetTempFileName()
	}

	AfterEach {
		Remove-Item $testFile
	}

	Context "Single INI file" {

		It "Finds settings without section in unnamed section" {
			$ini = LoadTestDataToFile $dataWithoutSection $testFile
	
			$ini['']['foo'] | Should Be 1
			$ini['']['bar'] | Should Be 'stuff'
		}

		It "Finds settings with single section" {
			$ini = LoadTestDataToFile $dataWithOneSection $testFile
	
			$ini['config']['color'] | Should Be 'green'
			$ini['config']['size'] | Should Be 0.5
			$ini['config']['265'] | Should Be 'true'
		}
	
		It "Finds settings with multiple sections" {
			$ini = LoadTestDataToFile $dataWithMultipleSections $testFile
	
			$ini['']['foo'] | Should Be 1
			$ini['config']['color'] | Should Be 'green'
			$ini['sizes']['a'] | Should Be 0.5
		}
	
		It "Finds distinct settings with same key in different sections" {
			$ini = LoadTestDataToFile $dataWithSameKeyInDifferentSections $testFile
			$ini['configA']['color'] | Should Be 'green'
			$ini['configB']['color'] | Should Be 'red'
		}
	
		It "Collects settings from repeated sections" {
			$ini = LoadTestDataToFile $dataWithRepeatedSections $testFile
			$ini['config']['size'] | Should Be 42
			$ini['config']['color'] | Should Be 'green'
		}
	}

	Context "Multi-valued setting" {
		It "Finds setting with one value" {
			$ini = LoadTestDataToFile $dataWithMultipleValues $testFile
			$ini['commands']['onecmd'] | Should Be 'command1'
		}
		It "Finds setting with two values" {
			$ini = LoadTestDataToFile $dataWithMultipleValues $testFile
			$expected = 'command2a','command2b'
			ArrayDifferences $ini['commands']['twocmd'] $expected | Should BeNullOrEmpty
		}
		It "Finds setting with multiple values" {
			$ini = LoadTestDataToFile $dataWithMultipleValues $testFile
			$expected = 'a','b','c','d' | % { "command4$_" }
			ArrayDifferences $ini['commands']['fourcmd'] $expected | Should BeNullOrEmpty
		}
	}

	Context "Multiple INI files" {
		BeforeEach {
			$testFile2 = [System.IO.Path]::GetTempFileName()
			$dataForFileOne | Set-Content $testFile
			$dataForFileTwo | Set-Content $testFile2
			$myIni = Get-IniFile $testFile
			$myIni = Get-IniFile $testFile2 $myIni
		}
	
		AfterEach {
			Remove-Item $testFile2
		}

		It "Finds single setting in different sections from multiple files" {
			$myIni['soloFile1']['a'] | Should Be 1
			$myIni['soloFile2']['b'] | Should Be 2
		}

		It "Finds single setting in same section from multiple files" {
			$myIni['config']['color'] | Should Be 'green'
			$myIni['config']['size'] | Should Be 25
		}

		It "Finds multiple settings in same section from multiple files" {
			$expected = 'A','B','C','D' | % { "command$_" }
			ArrayDifferences $myIni['commands']['cmd'] $expected | Should BeNullOrEmpty
		}

		It "Finds multiple settings that were single in each of multiple files" {
			$expected = 'foobar', 542
			ArrayDifferences $myIni['param']['sameKey'] $expected | Should BeNullOrEmpty
		}

		It "Finds single setting outside of section from multiple files" {
			$myIni['']['isolatedSettingOne'] | Should Be 'foo'
			$myIni['']['isolatedSettingTwo'] | Should Be 'bar'
		}
	}

	Context "Blank lines ignored" {
$data = @"
[section1]

s1=s1stuff

[section2]
s2=s2stuff
[section3]

s3=s3stuff
[section4]
s4=s4stuff

[section5]
s5a= extra spaces dropped  
s5b   =extra spaces dropped  
s5c   =    extra spaces dropped  
"@
		BeforeEach {
			$testFile3 = [System.IO.Path]::GetTempFileName()
			$ini = LoadTestDataToFile $data $testFile3
			Remove-Item $testFile3
		}

		It "Blank lines before and after" {
			$ini['section1']['s1'] | Should Be 's1stuff'
		}
		It "No blank lines" {
			$ini['section2']['s2'] | Should Be 's2stuff'
		}
		It "Blank lines before" {
			$ini['section3']['s3'] | Should Be 's3stuff'
		}
		It "Blank lines after" {
			$ini['section4']['s4'] | Should Be 's4stuff'
		}
		It "Leading/trailing blanks" {
			$ini['section5']['s5a'] | Should Be 'extra spaces dropped'
			$ini['section5']['s5b'] | Should Be 'extra spaces dropped'
			$ini['section5']['s5c'] | Should Be 'extra spaces dropped'
		}
	}

	Context "Comment lines ignored" {
$data = @"
[section1]
# s1a = comment
s1=s1stuff
# s1b = comment
[section2]
# s2a = comment
s2=s2stuff
[section3]
s3=s3stuff
# s3a = comment
"@
		BeforeEach {
			$testFile4 = [System.IO.Path]::GetTempFileName()
			$ini = LoadTestDataToFile $data $testFile4
			Remove-Item $testFile4
		}

		It "Comment lines before and after" {
			$ini['section1']['s1'] | Should Be 's1stuff'
			$ini['section1']['s1a'] | Should BeNullOrEmpty
			$ini['section1']['s1b'] | Should BeNullOrEmpty
		}
		It "Comment lines before" {
			$ini['section2']['s2'] | Should Be 's2stuff'
			$ini['section2']['s2a'] | Should BeNullOrEmpty
		}
		It "Comment lines after" {
			$ini['section3']['s3'] | Should Be 's3stuff'
			$ini['section3']['s3a'] | Should BeNullOrEmpty
		}
	}

	Context "Other interesting cases" {
$data = @"
[section1]
# lines without a key=value format are ignored
ignored
= also ignored
Val1=
UPPER=1.5
Val2=Val3=Val4
[section2]
"@
		BeforeEach {
			$testFile5 = [System.IO.Path]::GetTempFileName()
			$ini = LoadTestDataToFile $data $testFile5
			Remove-Item $testFile5
		}
		It "Returns correct sections" {
			$ini.GetEnumerator() | select -ExpandProperty name | sort |
			Should Be 'section1','section2'
		}
		It "Returns correct keys in a section" {
			$ini['section1'].GetEnumerator() |select -ExpandProperty key |sort|
			Should Be 'UPPER','Val1','Val2'
		}
		It "Returns no value for undefined entry" {
			$ini['section1']['Val1'] | Should Be ""
		}
		It "Returns value case-insensitively" {
			$ini['section1']['UPPER'] | Should Be $ini['section1']['upper']
		}
		It "Supports equals in the value" {
			$ini['section1']['Val2'] | Should Be 'Val3=Val4'
		}
		It "Ignores lines that are not key=value" {
			$ini['section1'].Count | Should Be 3
		}
		It "Does not create empty sections" {
			$ini['section2'] | Should Be $null 
		}
	}
}
}

