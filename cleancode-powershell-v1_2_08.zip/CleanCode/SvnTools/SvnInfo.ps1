﻿#
# ==============================================================
# @ID       $Id: SvnInfo.ps1 1395 2013-06-05 02:13:32Z ms $
# @created  2011-08-25
# @project  http://cleancode.sourceforge.net/
# ==============================================================
#
# The official license for this file is shown next.
# Unofficially, consider this e-postcardware as well:
# if you find this module useful, let us know via e-mail, along with
# where in the world you are and (if applicable) your website address.
#
#
# ***** BEGIN LICENSE BLOCK *****
# Version: MPL 1.1
#
# The contents of this file are subject to the Mozilla Public License Version
# 1.1 (the "License"); you may not use this file except in compliance with
# the License. You may obtain a copy of the License at
# http://www.mozilla.org/MPL/
#
# Software distributed under the License is distributed on an "AS IS" basis,
# WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
# for the specific language governing rights and limitations under the
# License.
#
# The Original Code is part of the CleanCode toolbox.
#
# The Initial Developer of the Original Code is Michael Sorens.
# Portions created by the Initial Developer are Copyright (C) 2011
# the Initial Developer. All Rights Reserved.
#
# Contributor(s):
#
# ***** END LICENSE BLOCK *****
#

Set-StrictMode -Version Latest
Import-Module CleanCode/FileTools

$ExcisionSeparator = ':'

<#

.SYNOPSIS
Returns output of the Subversion "svn info" command as PowerShell objects.

.DESCRIPTION
Get-SvnInfo provides a convenient interface to the Subversion "svn info" command.  Conventional output from "svn info" looks like this:

    --------------------------------------------------------------------
    > svn info CleanCode
    Path: C:/usr/ms/devel/CleanCode
    URL: file:///C:/usr/svn/cleancode/trunk/devel/powershell/CleanCode
    Repository Root: file:///C:/usr/svn/cleancode
    Repository UUID: 75eedc-7c4-14e-87a-88bfc6be1
    Revision: 1107
    Node Kind: directory
    Schedule: normal
    Last Changed Author: msorens
    Last Changed Rev: 1105
    Last Changed Date: 2011-08-12 15:54:10 -0700 (Fri, 12 Aug 2011)
    --------------------------------------------------------------------

Get-SvnInfo converts this text output into PowerShell objects and pivots the data from rows to columns. You then specify which columns you want to see using the Property list. You can feed one or more starting paths (Path parameter) and you can recurse through the directory tree from each starting point. Get-SvnInfo uses Get-ChildItem at its core so the standard -Recurse parameter works for Get-SvnInfo as it does for Get-ChildItem. (Actually, Get-SvnInfo uses the CleanCode variation, Get-EnhancedChildItem, which lets you easily focus on SVN-only files).

Once you pivot the output of "svn info" you could easily get excessive line lengths. Get-SvnInfo thus provides a handy mechanism for trimming any selected property, particularly useful if you select any path properties (e.g. Path, URL, Repository Root). See the Property parameter for particulars.

.PARAMETER ContainersOnly
Returns only containers (directories).

.PARAMETER Exclude
Omits the specified items. The value of this parameter qualifies the
Path parameter.
Enter a path element or pattern, such as "*.txt".

.PARAMETER ExcludeTree
Excludes not just a matching item but also all its children as well.

.PARAMETER Include
Retrieves only the specified items. The value of this parameter qualifies
the Path parameter. Enter a path element or pattern, such as "*.txt".

The Include parameter is effective only when the command includes
the Recurse parameter or the path leads to the contents of a directory,
such as C:\Windows\*, where the wildcard character specifies the contents
of the C:\Windows directory.

.PARAMETER Path
Specifies a path to one or more locations.
The default location is the current directory (.).

.PARAMETER Property
Specifies the properties to select. Wildcards are *not* permitted.
Each property in the list must match an existing field name returned by
the standard Subversion "svn info" command.
You may optionally qualify a property to return a trimmed version of
the field value by using the format "<field name>:<value to excise>".
The <value to excise> must be a constant string by default.
If you enable the use of regular expressions (see the UseRegex parameter)
then the <value to excise> for all properties must be a regular expression.

.PARAMETER Recurse
Gets the items in the specified locations and in all child items of the
locations. Recurse works only when the path points to a container that
has children, such as C:\Windows or C:\Windows\*, and not when it points
to items without children, such as C:\Windows\*.exe. The default is false.

.PARAMETER UseRegex
Set to true, this changes interpretation of trimming prefixes in the
Property parameter list from plain string to regular expression.
The default is false.

.INPUTS
System.String. You can pipe one or more path strings to Get-SvnInfo.

.OUTPUTS
Object. The type of object returned is determined by the provider with which it is used.

.EXAMPLE
PS> Get-SvnInfo "." @('Path', 'Revision')
Returns the Subversion Path and Revision properties for all SVN objects in the current directory.

    Path                                     Revision
    ----                                     --------
    C:\usr\powershell\scripts\AnalyzeMySv... 1107
    C:\usr\powershell\scripts\GenerateCle... 1122
    C:\usr\powershell\scripts\psdoc_templ... 1122
    C:\usr\powershell\scripts\RunNUnitGri... 1107

.EXAMPLE
PS> Get-SvnInfo "." @('Path', 'Revision') | Format-Table -AutoSize
Returns the Subversion Path and Revision properties for all SVN objects in the current directory. Piping the output through Format-Table is one way to show more useful output rather than the truncated output above.

    Path                                                              Revision
    ----                                                              --------
    C:\usr\devel\long\path\to\trim\scripts\AnalyzeMySvnKeywords.ps1   1107
    C:\usr\devel\long\path\to\trim\scripts\GenerateCleanCodeAPI.ps1   1122
    C:\usr\devel\long\path\to\trim\scripts\psdoc_template.html        1122
    C:\usr\devel\long\path\to\trim\scripts\RunNUnitGrid.ps1           1107

.EXAMPLE
PS> Get-SvnInfo "subdir1","subdir2" 'Path', 'Revision'
Returns the Subversion Path and Revision properties for all SVN objects in the two specified directories.

    Path                                             Revision
    ----                                             --------
    C:\usr\powershell\scripts\subdir1\AnalyzeMySv... 1107
    C:\usr\powershell\scripts\subdir1\GenerateCle... 1122
    C:\usr\powershell\scripts\subdir2\psdoc_templ... 1122
    C:\usr\powershell\scripts\subdir2\RunNUnitGri... 1107

.EXAMPLE
PS> Get-SvnInfo "." -Recurse Path, Revision, URL
Returns the specified Subversion properties for all SVN objects in the tree rooted at the current directory.

.EXAMPLE
PS> Get-SvnInfo "." -Recurse 'Path|C:\usr\devel\long\path\to\trim', 'Revision'
Returns the specified Subversion properties for all SVN objects in the tree rooted at the current directory, and trims the initial portion of each Path.

    Path                                Revision
    ----                                --------
    \scripts\AnalyzeMySvnKeywords.ps1   1107
    \scripts\GenerateCleanCodeAPI.ps1   1122
    \scripts\psdoc_template.html        1122
    \scripts\RunNUnitGrid.ps1           1107

.EXAMPLE
PS> Get-SvnInfo "." -Recurse -ContainersOnly Path, URL | Format-Table Path, @{ n='Branch'; e={$_.URL -replace ".*(trunk|branches/[^/]*).*", '$1'} }
Identifes the branch of each subdirectory in case you have mixed branches in your working copy.

.LINK
Get-EnhancedChildItem
.LINK
Get-SvnLog
.LINK
[TortoiseSVN and Subversion Cookbook Part 7: Managing Revisions] (http://www.simple-talk.com/dotnet/.net-tools/tortoisesvn-and-subversion-cookbook-part-7-managing-revisions/)
.LINK
[svn info] (http://svnbook.red-bean.com/en/1.7/svn.ref.svn.c.info.html)
.LINK
[svn command reference] (http://svnbook.red-bean.com/en/1.7/svn.ref.html)
.LINK
[The Subversion Book] (http://svnbook.red-bean.com/)

.NOTES
This function is part of the CleanCode toolbox
from http://cleancode.sourceforge.net/.

Since CleanCode 1.1.01.

#>

function Get-SvnInfo(
	[Parameter(Position=0, ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true)]
	[SupportsWildcards()]
	[string[]]${Path},

	[Parameter(Position=1)]
	[string[]]${Property},

	[SupportsWildcards()]
	[string[]]${Include},

	[SupportsWildcards()]
	[string[]]${Exclude},

	[SupportsWildcards()]
	[string[]]${ExcludeTree} = @(),

	[switch]${Recurse},

	[switch]${UseRegex},

	[Switch]${ContainersOnly}
)
{
	# Remove params *not* to pass to Get-EnhancedChildItem
	"Property","UseRegex" | % { $PSBoundParameters.Remove($_) } | Out-Null

	$propertyHash = $null
	if ($Property) { $propertyHash = $Property | ConvertTo-HashTable }

	Get-EnhancedChildItem -Svn @PSBoundParameters | % {
		$obj=new-object object
		svn info $_.fullname | % {
  			$name, $value = Match-Expression $_ '(.*?):\s+(.*)'
			if ($name -and !$propertyHash) {
   	  			Add-Member -inputobject $obj NoteProperty $name $value
			}
			elseif ($name -and $propertyHash.Keys -contains $name) {
				if ($propertyHash[$name]) { $value = $value -Replace $propertyHash[$name], "" }
   	  			Add-Member -inputobject $obj NoteProperty $name $value
			}
		}
		$obj
	}
}

function Match-Expression($string, $regex)
{
	if ($string -match $regex)
	{ $Matches[1..($Matches.Count-1)] }
	else { @() }
}

# Adapted from http://blogs.msdn.com/b/powershell/archive/2008/11/23/poshboard-and-convertto-hashtable.aspx
# Also see version 2 at http://blogs.msdn.com/b/powershell/archive/2008/11/23/convertto-hashtable-ps1-part-2.aspx
function ConvertTo-HashTable()
{
	Begin { $hash = @{} }
	Process
	{
		if (($pos = $_.IndexOf(':')) -ge 0) {
			$label, $trimmer = $_.Substring(0,$pos), $_.Substring($pos+1)
			$hash[$label] = switch ($UseRegex) {
				$true { $trimmer }
				$false { [Regex]::Escape($trimmer) }
			}
		}
		else { $hash[$_] = $null }
	}
	End { Write-Output $hash }
}

Export-ModuleMember Get-SvnInfo
