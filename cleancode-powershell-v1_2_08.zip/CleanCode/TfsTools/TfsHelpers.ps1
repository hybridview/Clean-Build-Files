#
# ==============================================================
# @ID       $Id: TfsHelpers.ps1 1560 2015-12-16 19:46:13Z ms $
# @created  2014-07-01
# @project  http://cleancode.sourceforge.net/
# ==============================================================
#
# The official license for this file is shown next.
# Unofficially, consider this e-postcardware as well:
# if you find this module useful, let us know via e-mail, along with
# where in the world you are and (if applicable) your website address.
#
#
# ***** BEGIN LICENSE BLOCK *****
# Version: MPL 1.1
#
# The contents of this file are subject to the Mozilla Public License Version
# 1.1 (the "License"); you may not use this file except in compliance with
# the License. You may obtain a copy of the License at
# http://www.mozilla.org/MPL/
#
# Software distributed under the License is distributed on an "AS IS" basis,
# WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
# for the specific language governing rights and limitations under the
# License.
#
# The Original Code is part of the CleanCode toolbox.
#
# The Initial Developer of the Original Code is Michael Sorens.
# Portions created by the Initial Developer are Copyright (C) 2011
# the Initial Developer. All Rights Reserved.
#
# Contributor(s):
#
# ***** END LICENSE BLOCK *****
#

Set-StrictMode -Version Latest

$tfCmd = 'tf.exe'

<#

.SYNOPSIS
Returns a single line indicating the latest version of any local file in a given subtree.

.DESCRIPTION
This will find the latest version number of any file rooted in the specified subtree.
Note that does *not* indicate that all files are at that version,
only that at least one is.
Thus you can use this cmdlet to affirm staleness if the reported version
is less than the repository's latest version, but you can not use it to affirm freshness.
Refer to Get-Stale* to delve into specifics of what is stale in your workspace.

.PARAMETER Path
The root of the subtree to check.
If omitted, uses the current directory.

.INPUTS
None. You cannot pipe objects to Get-TfsVersion.

.OUTPUTS
Text.

.NOTES
This function is part of the CleanCode toolbox
from http://cleancode.sourceforge.net/.

Since CleanCode 1.2.06.

.LINK
Get-StaleTfsFiles
.LINK
Get-StaleTfsFolders
.LINK
Get-StaleTfsProjects

#>

function Get-TfsVersion([string]$Path = '.')
{
	if (!(ConfirmVsCmdShell)) { return }
	& $tfCmd history $Path /r /noprompt /stopafter:1 /version:W
}


<#

.SYNOPSIS
Retrieves TFS changesets containing a specified pattern in the comment.

.DESCRIPTION
Get-TfsChangesetByComment provides a handy search facility for a TFS repository using regular expressions.
This is actually a decorator around the TFS PowerTools Get-TfsItemHistory cmdlet,
adding the ability to filter by contents of the comment attached to a changeset.

.PARAMETER Pattern
A regular expression to match against the Comment property.
If omitted, all changesets are returned.

.PARAMETER Path
The root of the subtree to check.
If omitted, uses the current directory.

.PARAMETER StopAfter
Retrieves at most the number of changesets that you specify.

.PARAMETER User
Filters the list of changesets to the named user.
You may specify the user with or without the domain,
e.g. 'your-domain\yoda' or 'yoda' will return equivalent results.

.INPUTS
None. You cannot pipe objects to Get-TfsChangesetByComment.

.OUTPUTS
Array of Microsoft.TeamFoundation.VersionControl.Client.Changeset

.EXAMPLE
PS> Get-TfsChangesetByComment -Pattern 'cleanup.*projects' -User fflintstone -StopAfter 10
Retrieves up to the 10 latest changesets matching the specified pattern for the given user.

.NOTES
This function is part of the CleanCode toolbox
from http://cleancode.sourceforge.net/.

Since CleanCode 1.2.06.

#>

function Get-TfsChangesetByComment(
	[string]$Pattern = ".*",
	[string]$Path = ".",
	[string]$StopAfter,
	[string]$User
)
{
	if (!(ConfirmPowerTools)) { return }

	# Remove params *not* to pass to Get-TfsItemHistory
	'Pattern','Path','StopAfter' | ForEach { $PSBoundParameters.Remove($_) } | Out-Null

	if ($StopAfter) {
		Get-TfsItemHistory -HistoryItem $Path -Recurse @PSBoundParameters |
		Where { $_.Comment -match $Pattern } |
		Select -First $StopAfter
	}
	else {
		Get-TfsItemHistory -HistoryItem $Path -Recurse @PSBoundParameters |
		Where { $_.Comment -match $Pattern }
	}
}


<#

.SYNOPSIS
Retrieves TFS details about each file and folder.

.DESCRIPTION
From the output (see example), you can tell things like:
  * whether your workspace copy is current (IsLatest true or false).
  * whether an item is completely new (IsInWorkspace will be False and VersionLocal will be 0).
  * whether an item is simply out-of-date (VersionLatest will be larger than VersionLocal).
  * whether you have edited the local item (ChangeType will be Edit rather than None).

Refer to Get-StaleTfsFiles to limit the output to stale items.
Refer to Get-StaleTfsFolders or Get-StaleTfsProjects to see a summary of stale files.

This is actually a decorator around the TFS PowerTools Get-TfsItemProperty cmdlet,
automatically scanning the whole subtree and separating out two additional properties,
the file name and the parent path.
This cmdlet is the workhorse for other cmdlets in this module.

.PARAMETER Path
The root of the subtree to check.
If omitted, uses the current directory.

.INPUTS
None. You cannot pipe objects to Get-TfsDetails.

.OUTPUTS
Array of PSCustomObjects (similar to Microsoft.TeamFoundation.VersionControl.Client.ExtendedItem).

.EXAMPLE
PS> cd Project; Get-TfsDetails | Format-Table -AutoSize
Tabular output will typically look better by piping to Format-Table as shown.

    Name                 IsInWorkspace IsLatest ChangeType HasOtherPendingChange IsBranch VersionLatest VersionLocal ParentPath
    ----                 ------------- -------- ---------- --------------------- -------- ------------- ------------ ----------
    Some.Folder                  False    False       None                 False    False         18275            0 $\Development\MyRoot.Dev...
    Some.Other.Folder            False     True       None                 False    False         18102        18102 $\Development\MyRoot.Dev...
    NetworkAdmin.csproj           True    False       None                 False    False         18097         2177 $\Development\MyRoot.Dev...
    AssemblyInfo.cs               True     True       None                 False    False         18097        18097 $\Development\MyRoot.Dev...
    ConnectionDialog.cs           True    False       None                 False    False         18097         1879 $\Development\MyRoot.Dev...

.NOTES
This function is part of the CleanCode toolbox
from http://cleancode.sourceforge.net/.

Since CleanCode 1.2.06.

.LINK
Get-StaleTfsFiles
.LINK
Get-StaleTfsFolders
.LINK
Get-StaleTfsProjects

#>

function Get-TfsDetails([string]$Path = '.')
{
	if (!(ConfirmPowerTools)) { return }
	Get-TfsItemProperty $Path -Recurse |
	% {
		Add-Member -InputObject $_ -NotePropertyMembers @{
			Name = Split-Path $_.SourceServerItem -Leaf;
			ParentPath = Split-Path $_.SourceServerItem -Parent;
		}
		$_
	}
}


<#

.SYNOPSIS
Retrieves a list of files where one or more files are not current with the TFS repository.

.DESCRIPTION
Returns details about files and folders that are not current with the TFS repository (see example).
As such, the IsLatest property will always show *False*.
Other properties indicate:
  * whether the item is completely new (IsInWorkspace will be False and VersionLocal will be 0).
  * whether the item is simply out-of-date (VersionLatest will be larger than VersionLocal).
  * whether you have edited the local item (ChangeType will be Edit rather than None).

Refer to Get-TfsDetails to see the same information on all files (current or not).
Refer to Get-StaleTfsFolders or Get-StaleTfsProjects to see a summary of stale files.

.PARAMETER Path
The root of the subtree to check.
If omitted, uses the current directory.

.INPUTS
None. You cannot pipe objects to Get-StaleTfsFiles.

.OUTPUTS
Array of PSCustomObjects (similar to Microsoft.TeamFoundation.VersionControl.Client.ExtendedItem).

.EXAMPLE
PS> cd Project; Get-StaleTfsFiles | Format-Table -AutoSize
Tabular output will typically look better by piping to Format-Table as shown.

    Name                IsInWorkspace IsLatest ChangeType IsBranch VersionLatest VersionLocal
    ----                ------------- -------- ---------- -------- ------------- ------------
    Some.Folder                 False    False       None    False         18275            0
    Some.Other.Folder           False    False       None    False         18102            0
    NetworkAdmin.csproj          True    False       None    False         18097         2177
    AssemblyInfo.cs              True    False       None    False         18097         1879
    ConnectionDialog.cs          True    False       None    False         18097         1879

.EXAMPLE
PS> Get-StaleTfsFiles | Select Name, Project, Folder
Depending on your window width you may not see all the object properties with Format-Table.
Pipe to Select-Object to see specific properties as shown here.

    Name                Project      Folder
    ----                -------      ------
    Some.Folder         Main         .\MyRoot.DevCore\src\Main\Infrastructure
    Some.Other.Folder   ??           .\MyRoot.DevCore\src
    NetworkAdmin.csproj NetworkAdmin .\MyRoot.DevCore\src\NetworkAdmin
    AssemblyInfo.cs     NetworkAdmin .\MyRoot.DevCore\src\NetworkAdmin\Properties
    ConnectionDialog.cs NetworkAdmin .\MyRoot.DevCore\src\NetworkAdmin\src

The '??' indicates that the file is above the level of project folders
so there is no associated project.
Note that you will also see an unknown marker for files that you
have never downloaded into your workspace (i.e. new files introduced by someone else).

.NOTES
This function is part of the CleanCode toolbox
from http://cleancode.sourceforge.net/.

Since CleanCode 1.2.06.

.LINK
Get-TfsDetails
.LINK
Get-StaleTfsFolders
.LINK
Get-StaleTfsProjects

#>

function Get-StaleTfsFiles([string]$Path = '.')
{
	$projectDirs = Get-ChildItem $Path *.*proj -Exclude *.proj -Recurse |
		ForEach { split-path $_.DirectoryName -leaf }

	if (!(ConfirmPowerTools)) { return }
	Get-TFSDetails $Path | Where { ($_.IsLatest -eq $false) -and ($_.DeletionId -eq 0) } |
	ForEach {
		$myPath = $_.ParentPath
		$result = @($projectDirs |
			Where { $myPath -match ('\\{0}(\\|$)' -f [regex]::escape($_))})
		$project = if ($result.Count -gt 0) { $result[0] } else { '??' }
		$relPath = '.' + ($myPath -replace (".*" + (Split-Path (Resolve-Path $Path) -Leaf)))

		[PSCustomObject] @{
			Name = $_.Name;
			IsInWorkspace = $_.IsInWorkspace;
			ChangeType = $_.ChangeType;
			CheckinDate = $_.CheckinDate;
			HasOtherPendingChange = $_.HasOtherPendingChange;
			IsBranch = $_.IsBranch;
			VersionLatest = $_.VersionLatest;
			VersionLocal = $_.VersionLocal;
			# Put these at the end for better output with Format-Table.
			Project = $project;
			Folder = $relPath
		}
	}
}


<#

.SYNOPSIS
Retrieves a list of folders where one or more files are not current with the TFS repository.

.DESCRIPTION
Summarizes what is stale in your workspace by folder.
Refer to Get-StaleTfsProjects to see a summary by project.
Refer to Get-StaleTfsFiles to see details per file.

.PARAMETER Path
The root of the subtree to check.
If omitted, uses the current directory.

.INPUTS
None. You cannot pipe objects to Get-StaleTfsFolders.

.OUTPUTS
Array of PSCustomObjects.

.EXAMPLE
PS> cd Project\Database; Get-StaleTfsFolders | Format-Table -AutoSize
Tabular output will typically look better by piping to Format-Table as shown.

    Folder                          Project          FileCount
    ------                          -------          ---------
    .                               ??                       1
    .\Subproject                    Subproject               9
    .\Subproject\Functions          Subproject               1
    .\Subproject\Jobs               Subproject               1
    .\Subproject\Procedures         Subproject              58
    .\Subproject\Roles              Subproject               3
    .\Subproject\SchemaCollections  Subproject               2
    .\Subproject\Tables             Subproject              45

The project column shows unknown (??) for the current (root) directory because
it is on top of all the projects within the folder, so there is no associated project.
Note that you will also see an unknown marker for files that you
have never downloaded into your workspace (i.e. new files introduced by someone else).

.NOTES
This function is part of the CleanCode toolbox
from http://cleancode.sourceforge.net/.

Since CleanCode 1.2.06.

.LINK
Get-TfsDetails
.LINK
Get-StaleTfsFiles
.LINK
Get-StaleTfsProjects

#>

function Get-StaleTfsFolders([string]$Path = '.')
{
	if (!(ConfirmPowerTools)) { return }
	Get-StaleTfsFiles $Path |
	Group Folder |
	Select @{n='Folder'; e={$_.Group[0].Folder}},
		@{n='Project'; e={$_.Group[0].Project}},
		@{n='FileCount'; e={$_.Count}}
}


<#

.SYNOPSIS
Retrieves a list of projects where one or more files are not current with the TFS repository.

.DESCRIPTION
Summarizes what is stale in your workspace by project.
Refer to Get-StaleTfsFolders to see a summary by folder.
Refer to Get-StaleTfsFiles to see details per file.

.PARAMETER Path
The root of the subtree to check.
If omitted, uses the current directory.

.INPUTS
None. You cannot pipe objects to Get-StaleTfsProjects.

.OUTPUTS
Array of PSCustomObjects.

.EXAMPLE
PS> cd Project\src; Get-StaleTfsProjects | Format-Table -AutoSize
Tabular output will typically look better by piping to Format-Table as shown.

    Project                         FileCount
    -------                         ---------
    Network.Installer.Admin                 2
    Network.Installer.Configuration         2
    Network.Interop                         1
    Network.Connection                     11
    WcfAdmin.ConfigurationProvider          2
    WcfAdmin.Console                        2
    WcfAdmin.Core                          38

Note that you may see a project named with an unknown marker ('??') that indicates
that there were some files that either:
* are above the level of project folders so do not have a containing project, or
* have never been downloaded into your workspace (i.e. new files introduced by someone else).

.NOTES
This function is part of the CleanCode toolbox
from http://cleancode.sourceforge.net/.

Since CleanCode 1.2.06.

.LINK
Get-TfsDetails
.LINK
Get-StaleTfsFiles
.LINK
Get-StaleTfsFolders
#>

function Get-StaleTfsProjects([string]$Path = '.')
{
	if (!(ConfirmPowerTools)) { return }
	Get-StaleTfsFiles $Path |
	Group Project |
	Select @{n='Project'; e={$_.Name}},
		@{n='FileCount'; e={$_.Count}}
}

function ConfirmPowerTools()
{
	$cmd = Get-Command Get-TfsItemHistory -ErrorAction SilentlyContinue
	if ($cmd -eq $null) {
		Write-Warning 'VS TFS 2013 PowerTools extension required--see http://bit.ly/1voD4HK'
		Write-Warning 'Then run "Add-PSSnapin Microsoft.TeamFoundation.PowerShell"'
		return $false
	}
	return $true
}

function ConfirmVsCmdShell()
{
	$cmd = Get-Command $tfCmd -ErrorAction SilentlyContinue
	$vs2013 = '12.0'
	if ($cmd -eq $null) {
		$script:tfCmd ="C:\Program Files (x86)\Microsoft Visual Studio $vs2013\Common7\IDE\TF.exe"
		$cmd = Get-Command $tfCmd -ErrorAction SilentlyContinue
		if ($cmd -eq $null) {
			Write-Warning 'cannot locate tf.exe in Visual Studio 2013 installation'
			return $false
		}
	}
	return $true
}

Export-ModuleMember Get-TfsVersion
Export-ModuleMember Get-TfsChangesetByComment
Export-ModuleMember Get-TfsDetails
Export-ModuleMember Get-StaleTfsFiles
Export-ModuleMember Get-StaleTfsFolders
Export-ModuleMember Get-StaleTfsProjects
