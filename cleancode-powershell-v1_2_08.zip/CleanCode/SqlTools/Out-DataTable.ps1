##########################################################################
# Source: http://gallery.technet.microsoft.com/scriptcenter/4208a159-a52e-4b99-83d4-8048468d29dd
# (obsoletes the version at http://poshcode.org/2954)
# Author: Chad Miller
# Date:   2012.07.20
# ** includes modification by msorens
##########################################################################

Set-StrictMode -Version Latest

<# 
.SYNOPSIS 
Creates a DataTable for an object.

.DESCRIPTION 
Creates a DataTable based on an object's properties. (Based on Chad Miller's original work--see Links section.)

.INPUTS 
Object. Any object can be piped to Out-DataTable.

.OUTPUTS 
System.Data.DataTable 

.PARAMETER InputObject
Specifies the objects to be converted to a DataTable.
If an array of objects is passed, any with a type that differs 
from the first object in the list are ignored and a warning is displayed.
To suppress the warning, use the TypeFilter parameter to pre-filter the list to a single type. 

.PARAMETER TypeFilter
Specifies a selection filter by data type name.
If not specified, all objects are processed and those with differing types
generate a warning message.
If TypeFilter is specified, only those objects matching the type name are processed.

.EXAMPLE 
$dt = Get-PsDrive | Out-DataTable 
This example creates a DataTable from the properties of Get-PsDrive and assigns output to the $dt variable.

.EXAMPLE
$dt = Get-ChildItem | Out-DataTable -TypeFilter FileInfo
This example creates a DataTable selecting only those objects that have type FileInfo (i.e. ignoring those of type DirectoryInfo, the other object output by Get-ChildItem).

.NOTES 
Adapted from script by Marc van Orsouw see link 
Version History 
v1.0  - Chad Miller - Initial Release 
v1.1  - Chad Miller - Fixed Issue with Properties 
v1.2  - Chad Miller - Added setting column datatype by property as suggested by emp0 
v1.3  - Chad Miller - Corrected issue with setting datatype on empty properties 
v1.4  - Chad Miller - Corrected issue with DBNull 
v1.5  - Chad Miller - Updated example 
v1.6  - Chad Miller - Added column datatype logic with default to string 

.LINK 
[PowerShell Guy's original](http://thepowershellguy.com/blogs/posh/archive/2007/01/21/powershell-gui-scripblock-monitor-script.aspx)
[Out-DataTable original by Chad Miller based on PowerGuy's](http://gallery.technet.microsoft.com/scriptcenter/4208a159-a52e-4b99-83d4-8048468d29dd)
Add-SqlTable
Write-DataTable
Out-SqlTable
#> 
function Out-DataTable 
{ 
    [CmdletBinding()] 
    param(
		[Parameter(Position=0, Mandatory=$true, ValueFromPipeline = $true)] [PSObject[]]$InputObject,
		[string]$TypeFilter
	)
 
    Begin 
    { 
        $dt = new-object Data.DataTable   
        $First = $true  
		$count = 0
    } 
    Process 
    { 
        foreach ($object in $InputObject) 
        { 
			# 2012.10.11 msorens: filter to silence warnings, too.
			if ($TypeFilter -and $object.GetType().Name -ne $TypeFilter) { continue }
			
			# 2012.10.11 msorens: warn about different types instead of throwing exception
			$count++
			if ($First) { $firstObjectType = $object.GetType() }
			elseif ( $object.GetType() -ne $firstObjectType) {
				Write-Warning ("Skipping {0}th object (type={1}, expected={2})" `
				-f $count, $object.GetType(), $firstObjectType)
				continue
			}
            $DR = $DT.NewRow()   
            foreach($property in $object.PsObject.get_properties()) 
            {   
                if ($first) 
                {   
                    $Col =  new-object Data.DataColumn   
                    $Col.ColumnName = $property.Name.ToString()   
                    # 2012.10.11 msorens: Modified test to allow zero to pass; 
					# otherwise, zero in the first record prevents data type assignment for the column. 
					$valueExists = Get-Member -InputObject $property -Name value
					if ($valueExists)
                    { 
						# 2012.10.11 msorens: Modified test for nulls to also include $null
                        if ($property.value -isnot [System.DBNull] -and $property.value -ne $null) {
                            $Col.DataType = [System.Type]::GetType("$(Get-Type $property.TypeNameOfValue)") 
                         } 
                    } 
                    $DT.Columns.Add($Col) 
                }
                # 2012.10.11 msorens: Changed from .IsArray because, when present, was null;
				# other times caused error (property 'IsArray' not found...).
                if ($property.Value -is [array]) {
                    $DR.Item($property.Name) = $property.value | ConvertTo-XML -AS String -NoTypeInformation -Depth 1 
                }   
                # 2012.10.11 msorens: Added support for XML fields
                elseif ($property.Value -is [System.Xml.XmlElement]) {
					$DR.Item($property.Name) = $property.Value.OuterXml
				}
                else { 
                    $DR.Item($property.Name) = $property.value 
                } 
            }   
            $DT.Rows.Add($DR)   
            $First = $false 
        } 
    }  
      
    End 
    { 
        Write-Output @(,($dt)) 
    } 
 
} #Out-DataTable 

####################### 
function Get-Type 
{ 
    param($type) 
 
$types = @( 
'System.Boolean', 
'System.Byte[]', 
'System.Byte', 
'System.Char', 
'System.Datetime', 
'System.Decimal', 
'System.Double', 
'System.Guid', 
'System.Int16', 
'System.Int32', 
'System.Int64', 
'System.Single', 
'System.UInt16', 
'System.UInt32', 
'System.UInt64') 
 
    if ( $types -contains $type ) { 
        Write-Output "$type" 
    } 
    else { 
        Write-Output 'System.String' 
         
    } 
} #Get-Type 
 
Export-ModuleMember Out-DataTable
