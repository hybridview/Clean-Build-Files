#
# ==============================================================
# @ID       $Id: SvnTrackerPattern.ps1 1560 2015-12-16 19:46:13Z ms $
# @created  2011-08-25
# @project  http://cleancode.sourceforge.net/
# ==============================================================
#
# The official license for this file is shown next.
# Unofficially, consider this e-postcardware as well:
# if you find this module useful, let us know via e-mail, along with
# where in the world you are and (if applicable) your website address.
#
#
# ***** BEGIN LICENSE BLOCK *****
# Version: MPL 1.1
#
# The contents of this file are subject to the Mozilla Public License Version
# 1.1 (the "License"); you may not use this file except in compliance with
# the License. You may obtain a copy of the License at
# http://www.mozilla.org/MPL/
#
# Software distributed under the License is distributed on an "AS IS" basis,
# WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
# for the specific language governing rights and limitations under the
# License.
#
# The Original Code is part of the CleanCode toolbox.
#
# The Initial Developer of the Original Code is Michael Sorens.
# Portions created by the Initial Developer are Copyright (C) 2011
# the Initial Developer. All Rights Reserved.
#
# Contributor(s):
#
# ***** END LICENSE BLOCK *****
#

Set-StrictMode -Version Latest

<#

.SYNOPSIS
Returns the TortoiseSVN "bugtraq:logregex" property of the closest parent to the specified item.

.DESCRIPTION
TortoiseSVN provides a very handy feature to add live links on your bug IDs in your commit messages connecting back to your bug tracking system.  This works with any bug tracking system that has a web interface.  (For example, I set up one system to point to a private installation of Jira and another to point to the publicly accessible SourceForge issue tracker.)

No additional effort is required to create these links other than to be sure to put your bug IDs in the log message into the correct format.  Furthermore, if you have been using the same standard format previously (without the convenience of links) it is automatically retroactive!  Once you or your admin configures Subversion with the "bugtraq" properties, all of your prior entries will also automatically display these links. 

TortoiseSVN provides a couple different ways to let you specify the format of your bug ID. I prefer the method that uses regular expressions which, though a bit more complicated, provides much more expressive power.  So with this method, the format is defined by a regular expression contained in the "bugtraq:logregex" property of the current folder.  If it isn't there, the property is automatically inherited by child folders unless explicitly overridden. 

This is different from standard Subversion properties (e.g. "svn:ignore") which must explicitly be attached to each folder in a hierarchy (either manually or by auto-prop rules) to be recognized.  The "bugtraq" properties are implicitly inherited--they do not need to be attached unless some descendant wishes to use a different value.

There is actually one reason you might want to propagate the same property value to descendants. If you put a "bugtraq" property on a project root it will apply to the entire project as long as you checkout from the root.  If you checkout a portion of your tree below the root, though, the property will not exist. 

So Get-IssueTrackerLogPattern traverses up the file tree until it finds the closest ancestor that defines a "bugtraq" property.  This is useful, for instance, in case different projects have adopted different formats for recognizing bug IDs.  Get-IssueTrackerLogPattern reports the format for a specified file or folder by walking up the tree until it finds the closest parent having the "bugtraq:logregex" pattern defined.  If it crawls to the working copy root finding no pattern, it reports "-none-". Use the common -Verbose parameter to see the treewalk.

As the TortoiseSVN documentation indicates, this pattern is used by
the TortoiseSVN project itself:

	[Ii]ssues?:?(\s*(,|and)?\s*#\d+)+
	(\d+)

Quoting the manual, "The first expression picks out 'issues #23, #24 and #25' from the surrounding log message. The second regex extracts plain decimal numbers from the output of the first regex, so it will return '23', '24', and '25' to use as bug IDs."

That is all true, but that pattern will also match "issues #23, #24 and#25" (note the missing space after the "and") and it will *not* match "issues #23, #24, and #25" (i.e. with an additional comma after the penultimate entry). This regex alleviates those issues:

	[Ii]ssues?:?(\s*(,|,?\s*and\s)?\s*#\d+)+ 

.PARAMETER Path
Specifies a path to one or more locations.
The default location is the current directory (.).

.INPUTS
System.String. You can pipe one or more path strings to Get-IssueTrackerLogPattern.

.OUTPUTS
String representing the log pattern for the input, or "-none-".

.EXAMPLE
PS> Get-IssueTrackerLogPattern
Returns the log pattern, if any, for the current directory.

.EXAMPLE
PS> Get-IssueTrackerLogPattern -Verbose
Returns the log pattern, if any, for the current directory and displays the path of each item from the current directory up to the last folder that is still a Subversion folder.

.EXAMPLE
PS> "Xyz*" | Get-IssueTrackerLogPattern
Returns the log pattern, if any, for each item in the current directory beginning with "Xyz".

.LINK
[TortoiseSVN and Subversion Cookbook: Part 8: Log Messages] (https://www.simple-talk.com/dotnet/.net-framework/tortoisesvn-and-subversion-cookbook-part-8-log-messages/)
.LINK
[Integration with Bug Tracking Systems / Issue Trackers] (http://tortoisesvn.net/docs/release/TortoiseSVN_en/tsvn-dug-bugtracker.html)
.LINK
[Integrating Subversion with your Issue Tracking System] (http://markphip.blogspot.com.es/2007/01/integrating-subversion-with-your-issue.html)
.LINK
[The TortoiseSVN Book] (http://tortoisesvn.net/docs/release/TortoiseSVN_en/index.html)
.LINK
[The Subversion Book] (http://svnbook.red-bean.com/)

.NOTES
This function is part of the CleanCode toolbox
from http://cleancode.sourceforge.net/.

Since CleanCode 1.1.02.

#>

function Get-IssueTrackerLogPattern
{
	# For the pattern used here to accept all valid direct AND pipeline inputs, see
	# http://www.simple-talk.com/dotnet/.net-tools/down-the-rabbit-hole--a-study-in-powershell-pipelines,-functions,-and-parameters/
	# I could have gotten by with a simpler model if I did not want to
	# include processing the -Verbose switch.
	[CmdletBinding()]
	param(
		[Parameter(ValueFromPipeline=$true)]
		[SupportsWildcards()]
		[string[]]${Path} = "."
	)
	$list = @($input)
	if ($list.count) { $Path = $list }
	if (! (Test-Path variable:\Path)) { $Path = "." }

	Get-Item $Path | % {
		$item = $null
		$trackerProperties = $null
		do {
			if ($item) { $item = Get-Item $item.PSParentPath }
			else { $item = $_ }
			Write-Verbose "$($item.FullName) ..."
			$trackerProperties = (& svn propget bugtraq:logregex $item.FullName 2>&1)
		} until ($LastExitCode -ne 0 -or !$item.PSParentPath -or $trackerProperties)

		if ($LastExitCode -eq 0 -and $trackerProperties) { $trackerProperties }
		else { "-none-" }
	}
}

Export-ModuleMember Get-IssueTrackerLogPattern
