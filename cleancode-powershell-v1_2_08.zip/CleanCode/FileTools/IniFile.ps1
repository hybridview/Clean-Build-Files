﻿#
# ==============================================================
# @ID       $Id: IniFile.ps1 1559 2015-12-14 17:15:23Z ms $
# @created  2011-07-01
# @project  http://cleancode.sourceforge.net/
# ==============================================================
#
# The official license for this file is shown next.
# Unofficially, consider this e-postcardware as well:
# if you find this module useful, let us know via e-mail, along with
# where in the world you are and (if applicable) your website address.
#
#
# ***** BEGIN LICENSE BLOCK *****
# Version: MPL 1.1
#
# The contents of this file are subject to the Mozilla Public License Version
# 1.1 (the "License"); you may not use this file except in compliance with
# the License. You may obtain a copy of the License at
# http://www.mozilla.org/MPL/
#
# Software distributed under the License is distributed on an "AS IS" basis,
# WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
# for the specific language governing rights and limitations under the
# License.
#
# The Original Code is part of the CleanCode toolbox.
#
# The Initial Developer of the Original Code is Michael Sorens.
# Portions created by the Initial Developer are Copyright (C) 2011
# the Initial Developer. All Rights Reserved.
#
# Contributor(s):
#
# ***** END LICENSE BLOCK *****
#

Set-StrictMode -Version Latest

<#

.SYNOPSIS
Gets a Windows INI file as a hash table.

.DESCRIPTION
Reads a standard INI file into a hash table allowing direct addressing of each section
and each dictionary entry (a key,value pair) within each section.
The standard INI format requires all entries to be within a section,
but for added flexibility, Get-IniFile allows entries to appear before
the first section in which case they are entered into an unnamed pseudo-section.

Only entries having the format "key=value" will be inserted into the hash.
Note that it is perfectly legal for a value to itself contain an equals sign;
the first equals sign on the line separates the key from the value.

Trailing spaces on any value line are dropped.
An octothorp at the beginning of a line comments out the line.

.PARAMETER fileName
Name of INI-formatted file.

.PARAMETER iniHash
A previously built hash table of INI settings. This is an optional parameter needed
only if you wish to build a hash table from multiple INI files.
Just pass the result of one call to Get-IniFile back in to the next call.

.INPUTS
None. You cannot pipe objects to Get-IniFile.

.OUTPUTS
System.Collections.Generic.Dictionary[string,string]

.EXAMPLE
PS> $myHash = Get-IniFile $myConfigFile; $myHash["auto"]["color"]

This example reads an INI file into a hash table then accesses a single value
(the "color" key under the "auto" section).

.EXAMPLE
PS> $myHash = Get-IniFile $myConfigFile; $myHash.GetEnumerator() | % { "section = $_.name " }; $myHash["auto"].GetEnumerator() | % { "auto[{0}] = {1}" -f $_.name, $_.value }

This example reads an INI file into a hash table, enumerates the section names,
then presuming there is a section named "auto", enumerates its keys and values.

.NOTES
Adapted from
http://stackoverflow.com/questions/417798/ini-file-parsing-in-powershell.

This function is part of the CleanCode toolbox
from http://cleancode.sourceforge.net/.

Since CleanCode 1.1.01.

#>

Function Get-IniFile ([string]$fileName, [hashtable]$iniHash = @{}) {
	$section = ''

	switch -regex -file $fileName {
		"^\s*\[\s*(\S+)\s*\]\s*$" {
			$section = $matches[1]
		}
		"^\s*([^#]+?)\s*=\s*(.*)" {
			$name,$value = $matches[1..2]
			if (!($iniHash[$section])) { $iniHash[$section] = @{} }

			# Here $value will always be a single string.
			AddValue $iniHash[$section] $name $value
		}
		"^\s*$" { }
		"^\s*#" { }
		default { Write-Error "Unrecognized data line: $_"}
	}
	$iniHash
}

Function AddValue([hashtable]$subhash, [string]$key, [string[]]$values)
{
	$values | % {
		$value = $_.Trim()
		# Support multi-valued properties
		if (!$subhash.ContainsKey($key)) {
			$subhash[$key] = $value # single value
		}
		elseif (($subhash[$key]).GetType().Name -eq 'String') {
			$subhash[$key] = @($subhash[$key], $value) # two values
		}
		else {
			$subhash[$key] = $subhash[$key] + $value #many values
		}
	}
}

Export-ModuleMember Get-IniFile