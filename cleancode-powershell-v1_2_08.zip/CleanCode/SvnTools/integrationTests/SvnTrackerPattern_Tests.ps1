﻿
Set-StrictMode -Version Latest
Import-Module CleanCode\Assertion
Import-Module CleanCode\SvnTools -Force

$root = "C:\usr\ms\devel"
if (! (Test-Path $root) ) { "Cannot run this test on this system"; exit 0 }

$actualRootPattern = & svn propget bugtraq:logregex $root

# BASICS
$results = Get-IssueTrackerLogPattern "$root\powershell\CleanCode"
Assert-Expression -Label 'Grandchild' $results $actualRootPattern
$results = Get-IssueTrackerLogPattern "$root\powershell"
Assert-Expression -Label 'Child' $results $actualRootPattern
$results = Get-IssueTrackerLogPattern $root
Assert-Expression -Label 'Self' $results $actualRootPattern

# DIRECT INPUTS
cd "$root\powershell"
$results = Get-IssueTrackerLogPattern
Assert-Expression -Label 'No input' $results $actualRootPattern
#$results = Get-IssueTrackerLogPattern $null
#Assert-Expression -Label 'Null input' $results $actualRootPattern
#$results = Get-IssueTrackerLogPattern ""
#Assert-Expression -Label 'Empty input' $results $actualRootPattern

# NB: The pipeline on the $expected flattens the results to a single array
$results = Get-IssueTrackerLogPattern "$root\p*" -Verbose
$expected = $actualRootPattern,$actualRootPattern,"-none-" | % { $_ }
Assert-Expression -Label 'Child-multiple' $results $expected

# PIPELINE INPUTS
$results = @() | Get-IssueTrackerLogPattern
Assert-Expression -Label 'Child-pipeline-empty list' $results $actualRootPattern
#$results = $null | Get-IssueTrackerLogPattern
#Assert-Expression -Label 'Child-pipeline-null' $results $actualRootPattern
#$results = "" | Get-IssueTrackerLogPattern
#Assert-Expression -Label 'Child-pipeline-empty' $results $actualRootPattern
$results = "$root\powershell" | Get-IssueTrackerLogPattern
Assert-Expression -Label 'Child-pipeline-one arg' $results $actualRootPattern
$results = "$root\p*" | Get-IssueTrackerLogPattern
Assert-Expression -Label 'Child-pipeline-multiple' $results $expected

Get-AssertCounts # 8 and 0
