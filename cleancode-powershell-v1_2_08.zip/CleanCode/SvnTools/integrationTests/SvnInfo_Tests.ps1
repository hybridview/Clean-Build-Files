﻿
Set-StrictMode -Version Latest
Import-Module CleanCode\Assertion
Import-Module CleanCode\SvnTools -Force

function Get-PropertyCount($results)
{
	$properties = $results | Get-Member -MemberType NoteProperty
	if ($properties -is [array]) { $properties.Count }
	else { 1 }
}

$root = "C:\usr\ms\devel"
if (! (Test-Path $root) ) { "Cannot run this test on this system"; exit 0 }
cd "$root\powershell"

$results = Get-SvnInfo "."
Assert-Expression -Label 'Property count' (Get-PropertyCount($results)) 11

$results = Get-SvnInfo "." @('Path', 'Revision')
Assert-Expression -Label 'Result count' $results.Count 3
Assert-Expression -Label 'Property count' (Get-PropertyCount($results)) 2
# Why has "svn info" stopped returning full paths...?!
#Assert-Expression -Label 'Untrimmed path' $results[0].Path "$root\powershell\CleanCode"
Assert-Expression -Label 'Untrimmed path' $results[0].Path "CleanCode"
#Assert-Expression -Label 'Untrimmed path' $results[1].Path "$root\powershell\scripts"
Assert-Expression -Label 'Untrimmed path' $results[1].Path "profile"
Assert-Expression -Label 'Number' ($results[0].Revision -match '^\d+') $true

$results = Get-SvnInfo "." @('Path', 'BadName')
Assert-Expression -Label 'Result count' $results.Count 3
Assert-Expression -Label 'Property count' (Get-PropertyCount($results)) 1
Assert-Expression -Label 'Non-existent' `
	( $results[0] | Get-Member -MemberType NoteProperty | ? {$_.Name -eq 'BadName'} ) $null

$results = Get-SvnInfo "." @("Path:$root", 'Revision')
Assert-Expression -Label 'Result count' $results.Count 3
Assert-Expression -Label 'Property count' (Get-PropertyCount($results)) 2
#Assert-Expression -Label 'Trimmed path' $results[0].Path "\powershell\CleanCode"
Assert-Expression -Label 'Trimmed path' $results[0].Path "CleanCode"
#Assert-Expression -Label 'Trimmed path' $results[1].Path "\powershell\scripts"
Assert-Expression -Label 'Trimmed path' $results[1].Path "profile"

$results = Get-SvnInfo ".","scripts" @("Path:$root", "URL:C:/usr/svn/cleancode/trunk/devel/", 'Revision')
Assert-Expression -Label 'Result count' $results.Count 10
Assert-Expression -Label 'Property count' (Get-PropertyCount($results)) 3
Assert-Expression -Label 'Trimmed path-middle' $results[0].Url "file:///powershell/CleanCode"

$results = Get-SvnInfo -Property @("Path:$root", "URL:C:/usr/svn/cleancode/trunk/devel/", 'Revision')
Assert-Expression -Label 'Result count, no path specified' $results.Count 3
Assert-Expression -Label 'Property count, no path specified' (Get-PropertyCount($results)) 3

$results = Get-SvnInfo "." @("URL:C:/usr/svn/cleancode/trunk/devel/")
$resultsB = Get-SvnInfo "." @("URL:C:/usr/svn/foobar/trunk/devel/")
Assert-Expression -Label 'Result count, no path specified' $results.Count 3
Assert-Expression -Label 'Property count, no path specified' (Get-PropertyCount($results)) 1
Assert-Expression -Label 'Property with matched trim string' $results[0].Url "file:///powershell/CleanCode" 
Assert-Expression -Label 'Property with unmatched trim string' $resultsB[0].Url "file:///C:/usr/svn/cleancode/trunk/devel/powershell/CleanCode" 

Get-AssertCounts # 21 and 0
