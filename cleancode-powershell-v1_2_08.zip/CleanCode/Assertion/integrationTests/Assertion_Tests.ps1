
Set-StrictMode -Version Latest
Import-Module CleanCode\Assertion -Force

#Set-AbortOnError 1
Assert-Expression -Label 'zero equality' 0 0   # pass
Assert-Expression -Label 'numerical inequality' 1 0
Assert-Expression -Label 'number vs null' 2 $null
Assert-Expression -Label 'number vs empty string' 3 ""
Assert-Expression -Label 'number vs empty list' 4 @()
Assert-Expression -Label 'null vs number' $null 5
Assert-Expression -Label 'empty string vs number' "" 6
Assert-Expression -Label 'empty list vs number' @() 7
Assert-Expression -Label 'empty list vs null' @() $null
Assert-Expression -Label 'empty list vs empty string' @() ""
Assert-Expression -Label 'empty list vs empty list' @() @()   # pass
Assert-Expression -Label 'string vs empty string' "[a1]" ""
Assert-Expression -Label 'string vs null' "[a2]" $null
Assert-Expression -Label 'string vs empty list' "[a3]" @()
Assert-Expression -Label 'string vs string equality' "[a4]" "[a4]"   # pass
Assert-Expression -Label 'string vs string inequality' "[a5]" "[b5]"
Assert-Expression -Label 'string vs list partial match' "[abc]" "[abc]","[def]","[ghi]"
Assert-Expression -Label 'string vs list no match' "[ghi]" "[abc]","[def]","[ghi]"
Assert-Expression -Label 'list vs string partial match' "[abc]","[def]","[ghi]" "[abc]"
Assert-Expression -Label 'list vs list partial match' "[abc]","[def]","[ghi]" "[abc]","[df]","[ghi]","[jkl]","[mno]"
Assert-Expression -Label 'list vs list equality' "[abc]","[def]","[ghi]" "[abc]","[def]","[ghi]"   # pass

Assert-Expression -Label 'mathematical expression vs number' (2 + 5) 7 # pass
Assert-Expression -Label 'mathematical function vs number' ([Math]::Min(-5,-9)) -9 # pass

$list = "item1", "item2", "item3", "item4"
Assert-Expression -Label 'list variable vs literal' $list "item1", "item2", "item3", "item4"

New-Module -scriptblock {function Double($count) { $count * 2}} | Out-Null
Assert-Expression -Label 'module function evaluation with constant' (Double(25)) 50
$myNum = 99
Assert-Expression -Label 'module function evaluation with variable' (Double($myNum)) 198

function AssertWithVariable() {
	$myCount = 16.3; Assert-Expression -Label 'module function evaluation in nested function' (Double($myCount)) 32.6
}
AssertWithVariable

Write-Host ('#' * 45)
Write-Host 'EXPECTING:'
Write-Host '    results to report 10 passing, 17 failing'
Write-Host 'ACTUAL:'
Get-AssertCounts # 10 and 17
Write-Host ('#' * 45)
