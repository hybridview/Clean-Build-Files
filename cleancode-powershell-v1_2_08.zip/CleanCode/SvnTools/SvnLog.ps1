#
# ==============================================================
# @ID       $Id: SvnLog.ps1 1560 2015-12-16 19:46:13Z ms $
# @created  2012-06-01
# @project  http://cleancode.sourceforge.net/
# ==============================================================
#
# The official license for this file is shown next.
# Unofficially, consider this e-postcardware as well:
# if you find this module useful, let us know via e-mail, along with
# where in the world you are and (if applicable) your website address.
#
#
# ***** BEGIN LICENSE BLOCK *****
# Version: MPL 1.1
#
# The contents of this file are subject to the Mozilla Public License Version
# 1.1 (the "License"); you may not use this file except in compliance with
# the License. You may obtain a copy of the License at
# http://www.mozilla.org/MPL/
#
# Software distributed under the License is distributed on an "AS IS" basis,
# WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
# for the specific language governing rights and limitations under the
# License.
#
# The Original Code is part of the CleanCode toolbox.
#
# The Initial Developer of the Original Code is Michael Sorens.
# Portions created by the Initial Developer are Copyright (C) 2011
# the Initial Developer. All Rights Reserved.
#
# Contributor(s):
#
# ***** END LICENSE BLOCK *****
#

Set-StrictMode -Version Latest


<#

.SYNOPSIS
Converts Subversion log data to PowerShell objects for easy statistical analysis.

.DESCRIPTION

Through Subversion's command line interface you have access to all of your log data, but it is designed for human consumption, not machine consumption. Each revision is output with a header line containing revision, user, and date; subsequent lines contain the associated log message, which may occupy multiple lines.

    PS powershell> svn log
    ------------------------------------------------------------------------
    r1186 | ww | 2011-11-07 20:33:48 -0800 (Mon, 07 Nov 2011) | 1 line
  
    Version update and other minor bookkeeping for next CleanCode release (1.1.02).
    ------------------------------------------------------------------------
    r1185 | ww | 2011-11-07 15:15:07 -0800 (Mon, 07 Nov 2011) | 2 lines
  
    Changed server-relative path for CSS to absolute URL to make testing a lot easier.
    Added new favicon reference for PowerShell library.
    ------------------------------------------------------------------------
    r1183 | ww | 2011-11-06 20:52:15 -0800 (Sun, 06 Nov 2011) | 1 line
  
    New function to identify log patterns used by TortoiseSVN.
    ------------------------------------------------------------------------
  
If you add the verbose option, you then get additional detail for each file associated with the revision:

    PS powershell> svn log -v
    ------------------------------------------------------------------------
    r1186 | ww | 2011-11-07 20:33:48 -0800 (Mon, 07 Nov 2011) | 1 line
    Changed paths:
       M /trunk/devel/powershell/CleanCode/Assertion/Assertion.psd1
       M /trunk/devel/powershell/CleanCode/DocTreeGenerator/DocTreeGenerator.psd1
       M /trunk/devel/powershell/CleanCode/EnhancedChildItem/EnhancedChildItem.psd1
       M /trunk/devel/powershell/CleanCode/FileTools/IniFile.psd1
       M /trunk/devel/powershell/CleanCode/SvnTools/SvnTools.psd1
  
    Version update and other minor bookkeeping for next CleanCode release (1.1.02).
    ------------------------------------------------------------------------
    r1185 | ww | 2011-11-07 15:15:07 -0800 (Mon, 07 Nov 2011) | 2 lines
    Changed paths:
       M /trunk/devel/powershell/scripts/psdoc_template.html
  
    Changed server-relative path for CSS to absolute URL to make testing a lot easier.
    Added new favicon reference for PowerShell library.
    ------------------------------------------------------------------------
    r1183 | ww | 2011-11-06 20:52:15 -0800 (Sun, 06 Nov 2011) | 1 line
    Changed paths:
       A /trunk/devel/powershell/CleanCode/SvnTools/SvnTrackerPattern.Tests.ps1
       A /trunk/devel/powershell/CleanCode/SvnTools/SvnTrackerPattern.ps1
  
    New function to identify log patterns used by TortoiseSVN.
    ------------------------------------------------------------------------

Each file line consists of an action code and a file path. The action codes (from http://svnbook.red-bean.com/en/1.7/svn.ref.svn.c.log.html) are:
    A    The item was added.
    D    The item was deleted.
    M    Properties or textual contents on the item were changed.
    R    The item was replaced by a different one at the same location.

Again, that is all fine for human consumption, but not for easy machine consumption to analyze and report on this raw data. Fortunately, the svn log command also provides an output-to-xml option that makes it a lot easier to consume:

    ------------------------------------------------------------------------
    PS powershell> svn log -v --xml
    <?xml version="1.0" encoding="UTF-8"?>
    <log>
    <logentry
       revision="1185">
    <author>ww</author>
    <date>2011-11-07T23:15:07.070258Z</date>
    <paths>
    <path
       kind=""
       action="M">/trunk/devel/powershell/scripts/psdoc_template.html</path>
    </paths>
    <msg>Changed server-relative path for CSS to absolute URL to make testing a lot easier.
    Added new favicon reference for PowerShell library.</msg>
    </logentry>
    <logentry
       revision="1183">
    <author>ww</author>
    <date>2011-11-07T04:52:15.434153Z</date>
    <paths>
    <path
       kind=""
       action="A">/trunk/devel/powershell/CleanCode/SvnTools/SvnTrackerPattern.ps1</path>
    <path
       kind=""
       action="A">/trunk/devel/powershell/CleanCode/SvnTools/SvnTrackerPattern.Tests.ps1</path>
    </paths>
    <msg>New function to identify log patterns used by TortoiseSVN.</msg>
    </logentry>
    . . .
    ------------------------------------------------------------------------

So with all that background, the Get-SvnLog function simply converts the output of "svn log -v --xml" to PowerShell objects so you can then peform complex analysis and identify things like:
*  List files committed by developer x since date y.
*  Show author and date for each revision in a specific range of revisions.
*  Summarize how many files have been committed by each user.
*  List the 10 most frequently committed files.
*  Show number of commits per day.

See the Examples section for a plethora of examples.

.PARAMETER Path
Specifies the working copy path or URL to examine. 
If omitted, defaults to the current directory.

.PARAMETER TagPath
Normally you limit the scope of 'svn log' by specifying a numerical 
range of revisions. Get-SvnLog improves on that by also letting you
specify tags instead of numerical values for the RevisionRange parameter.
When you do so, you must also specify a TagPath in which the
RevisionRange value (or values) are leaf nodes.

.PARAMETER RevisionRange
With no revision specified, the underlying call to svn log uses a revision
range of BASE to 1 (BASE:1) for a local path or HEAD to 1 (HEAD:1) for a URL.
HEAD is the latest version of a given branch. BASE is the revision number
of your working copy; so if you have not done an SVN Update in a while this
could be less than HEAD and you would not get data for all your revisions.

.PARAMETER ByFile
The Subversion log is by default organized by revision. 
Each revision is a commit of one or more files. Without this switch,
Get-SvnLog maps each revision to a PowerShell object.
With the switch, Get-SvnLog maps each file of each revision to
a PowerShell object, allowing you to explore different dimensions of your data.

.INPUTS
None. You cannot pipe objects to Get-SvnLog.

.OUTPUTS
Custom object.
By default, there is one object per revision, and each object contains Author, Revision, Date, Msg, and Paths properties.  The Paths property is a collection of all the files associated with the revision.  With the -ByFile option, each object contains Author, Revision, Date, Action, Msg and Path properties, and there is one object for each file touched in each revision.

.EXAMPLE
PS> Get-SvnLog | Format-Table -AutoSize
Show all fields of log data for all revisions.

.EXAMPLE
PS> Get-SvnLog | select Revision, Author, Date, Msg | Format-Table -AutoSize
Show all fields but omit file details (similar to the top pane of TortoiseSVN's log viewer).

.EXAMPLE
PS> Get-SvnLog | select Revision, Author, Date, Msg | Where Msg -match Jira-1234 | Format-Table -AutoSize
Show all the revisions containing a given string (e.g. an issue number) in the commit message.

.EXAMPLE
PS> Get-SvnLog -ByFile | ? Path -match "csproj" | select Revision, Date, Action, Path | Format-Table -AutoSize
Show commit details of all file names containing "csproj" (C# project files).  If, for example, a file that you expect is missing, this can quickly show you when it was added and when it was deleted.

.EXAMPLE
PS> Get-SvnLog -ByFile | Format-Table -AutoSize
Show all fields of log data for all files (i.e. all files within each revision).

.EXAMPLE
PS> Get-SvnLog -ByFile | % { $_.path }
Show just paths for all files.

.EXAMPLE
PS> Get-SvnLog -ByFile -RevisionRange 29400:29505 | % { $_.path } | Sort-Object -Unique
Show all files modified in a selected range of revisions.  A "native" way to do the equivalent operation in Subversion is "svn diff -r 29400:29505 --summarize".

.EXAMPLE
PS> Get-SvnLog -RevisionRange "12000:13500" | Format-Table -AutoSize
Show properties for each revision in a specific range of revisions.

.EXAMPLE
PS> Get-SvnLog -TagPath http://myproject/tags -RevisionRange "v1_15:v1_16"
Show properties for each revision between the two tags.

.EXAMPLE
PS> Get-SvnLog -ByFile | ? { $_.author -eq "smith" -and $_.date -ge (Get-Date "5/24/2012") } | Format-Table -AutoSize
Identify files committed by a specific developer since a given date.

.EXAMPLE
PS> Get-SvnLog -ByFile | group author | select name, count | Format-Table -AutoSize
Show summary of files for each author (unsorted).

.EXAMPLE
PS> Get-SvnLog -ByFile | group author | select name, count | sort name | Format-Table -AutoSize
Show summary of files for each author (sorted) using default property names "name" and "count".

.EXAMPLE
PS> Get-SvnLog -ByFile | group author | select @{ n='Author'; e={$_.name} }, count | sort name | Format-Table -AutoSize
Show summary of files for each author (sorted) with more applicable property names.

.EXAMPLE
PS> Get-SvnLog -ByFile | group path | sort count -Descending | select @{ n='Path'; e={$_.name} }, count -First 10 | Format-Table -AutoSize
Show top 10 most frequently committed files.

.EXAMPLE
PS> Get-SvnLog | group {$_.Date.ToString("yyyy-MM-dd")} | sort name -Descending | select @{n='Date'; e={$_.Name}}, Count | Format-Table -AutoSize
Show number of commits per day.

.EXAMPLE
PS> Get-SvnLog -ByFile | ? { $_.Author -eq 'smith' } | select  Revision,Date,Path | sort -property @{ Expression="Path";     Descending=$false }, @{ Expression="Revision"; Descending=$true  } | Format-Table -AutoSize
Show files committed by a particular author; a file may appear multiple times (includes each time author committed file).

.EXAMPLE
PS> Get-SvnLog -ByFile | ? { $_.Author -eq 'smith' } | group Path | select @{ n='Last Touched'; e={@($_.group | sort date -Descending)[0].date} }, @{ n='NumberOfTimesTouched'; e={$_.count} }, name | sort name | Format-Table -AutoSize
Show files committed by a particular author; each file appears just once with a count of commits and last committed date.

.EXAMPLE
PS> Get-SvnLog -ByFile | ? { $_.Date -ge (Get-Date).AddDays(-1) } | group Path | select @{ n='Date'; e={@($_.group | sort date -Descending)[0].date} }, @{ n='Path'; e={ $_.name} } | sort Date -Descending | Format-Table -AutoSize
Show files committed within the last 24 hours; each file appears just once with the latest commit time.

.EXAMPLE
PS> Get-SvnLog -ByFile | select Revision,Author,Date,Path |? { $_.Date -ge (Get-Date((Get-Date).AddDays(-1))) } | sort -property @{ Expression="Path"; Descending=$false }, @{ Expression="Revision"; Descending=$true } | Format-Table -AutoSize
Show all commits within the last 24 hours; files may appear multiple times .

.EXAMPLE
PS> Get-SvnLog -ByFile | ? { $_.Date -ge (Get-Date((Get-Date).AddDays(-1).ToString("yyyy-MM-dd"))) } | group Path | select @{ n='Date'; e={@($_.group | sort date -Descending)[0].date} }, @{ n='Author'; e={@($_.group | sort date -Descending)[0].author} }, @{ n='Path'; e={ $_.name} } | sort Date -Descending | Format-Table -AutoSize
Show files committed since yesterday and by whom.

.LINK
Get-SvnInfo
.LINK
[svn log] (http://svnbook.red-bean.com/en/1.7/svn.ref.svn.c.log.html)
.LINK
[svn command reference] (http://svnbook.red-bean.com/en/1.7/svn.ref.html)
.LINK
[The Subversion Book] (http://svnbook.red-bean.com/)

.NOTES
This function is part of the CleanCode toolbox
from http://cleancode.sourceforge.net/.

Since CleanCode 1.1.04.

#>

Function Get-SvnLog(
	[string]$Path = ".",
	[string]$TagPath,
	[string]$RevisionRange,
	[switch]$ByFile
)
{
    # patch: "svn log ." can fail on Windows if you chdir'ed to a path 
    # with incorrect case, e.g. "cd \temp" instead of "cd \Temp".
    # But "svn log $pwd" works regardless of casing!
    if ($Path -eq ".") { $Path = $pwd }

	try {
		if ($TagPath) {
			$mappedRange = Convert-TagsToRevisions $TagPath $RevisionRange
			# store it only if no exception
			$RevisionRange = $mappedRange
		}
		elseif ($RevisionRange -and $RevisionRange -notmatch "^\d+(:\d+)?$")
		{
			Write-Warning "Missing TagPath with non-numeric revision range"
			return $null
		}
	}
	catch {
		Write-Warning "Non-existent tag(s): '$RevisionRange'"
		return $null
	}
	
	if ($RevisionRange) { $RevisionRange = "-r$RevisionRange" }
	
	$logData = $null
	try {
		# Capture stderr to prevent ugly error message on failure.
		$rawdata = svn log $Path -v --xml $RevisionRange 2>&1
		$logData = [xml]$rawdata
	}
	catch { }
	# Can have no data either from an exception above on a range,
	# or on a single revision which simply returns an empty log node.
	if (!$logData -or !$logData.log) {
		Write-Warning "No data for specified revision(s): '$RevisionRange'";
		return $null
	}
	
	if ($ByFile) {
		$logData.log.logentry | % {
			$nestedEntry = $_
			$_.paths.path | % {
				$nextpath = $_
				$nestedEntry | Select-Object -Property `
				    @{n='Author';   e={$_.author          }}, `
					@{n='Revision'; e={([int]$_.revision) }}, `
					@{n='Date';     e={Get-Date $_.date   }}, `
					@{n='Action';   e={$nextpath.Action   }}, `
					@{n='Path';     e={$nextpath.InnerText}}, `
					@{n='Message';  e={$_.msg             }}`
			}
		}
	}
	else {
		$logData.log.logentry |
			Select-Object -Property `
				@{n='Author';   e={$_.author         }}, `
				@{n='Revision'; e={([int]$_.revision)}}, `
				@{n='Date';     e={Get-Date $_.date  }}, `
				@{n='Message';  e={$_.msg            }}, `
				@{n='Paths';    e={$_.paths.OuterXml }}
	}
}

function Convert-TagsToRevisions($tagPath, $range)
{
	# Capture stderr to prevent ugly error message on failure.
	($range -split ':'  |
		% { ([xml](svn info --xml "$tagPath/$_" 2>&1)).info.entry.commit.revision }) -join ':'
	# alternate:
	# ([xml](svn log --xml --stop-on-copy "$tagPath/$_")).log.logentry.revision
}

Export-ModuleMember Get-SvnLog
