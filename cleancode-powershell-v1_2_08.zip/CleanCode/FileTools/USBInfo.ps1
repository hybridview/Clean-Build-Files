#
# ==============================================================
# @ID       $Id: USBInfo.ps1 1395 2013-06-05 02:13:32Z ms $
# @created  2012-08-01
# @project  http://cleancode.sourceforge.net/
# ==============================================================
#
# The official license for this file is shown next.
# Unofficially, consider this e-postcardware as well:
# if you find this module useful, let us know via e-mail, along with
# where in the world you are and (if applicable) your website address.
#
#
# ***** BEGIN LICENSE BLOCK *****
# Version: MPL 1.1
#
# The contents of this file are subject to the Mozilla Public License Version
# 1.1 (the "License"); you may not use this file except in compliance with
# the License. You may obtain a copy of the License at
# http://www.mozilla.org/MPL/
#
# Software distributed under the License is distributed on an "AS IS" basis,
# WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
# for the specific language governing rights and limitations under the
# License.
#
# The Original Code is part of the CleanCode toolbox.
#
# The Initial Developer of the Original Code is Michael Sorens.
# Portions created by the Initial Developer are Copyright (C) 2011
# the Initial Developer. All Rights Reserved.
#
# Contributor(s):
#
# ***** END LICENSE BLOCK *****
#

#
# Adapted from Post by Christian on this SO question:
# http://stackoverflow.com/questions/10634396/how-do-i-get-the-drive-letter-of-a-usb-drive-in-powershell

Set-StrictMode -Version Latest

<#

.SYNOPSIS
Convenience function for obtaining USB drive information.

.DESCRIPTION
Returns ManagementObject objects that describe USB drives on the local system.  This function is the base used by Get-UsbDriveLetter and Get-UsbDriveCapacity, which simply select properties of the returned objects.

.INPUTS
None. You cannot pipe objects to Get-UsbDriveInfo.

.OUTPUTS
Array of System.Management.ManagementObject#root\cimv2\Win32_LogicalDisk.

.NOTES
The OutputType attribute is specified as System.Management.ManagementObject[]
though a more accurate type, returned by this...
     Get-UsbDriveInfo | Get-Member | Select -First 1 | % { $_.TypeName }
...is this:
     System.Management.ManagementObject#root\cimv2\Win32_LogicalDisk
but I am not sure how to specify that in the OutputType.

This function is part of the CleanCode toolbox
from http://cleancode.sourceforge.net/.

Since CleanCode 1.1.04.

.LINK
Get-UsbDriveLetter
.LINK
Get-UsbDriveCapacity

#>

function Get-UsbDriveInfo {
[OutputType([System.Management.ManagementObject[]])]
param()

    Get-WmiObject win32_diskdrive |
    Where-Object { $_.interfacetype -eq "USB" } |
    ForEach-Object {
    	Get-WmiObject -Query "ASSOCIATORS OF {Win32_DiskDrive.DeviceID=`"$($_.DeviceID.replace('\','\\'))`"} WHERE AssocClass = Win32_DiskDriveToDiskPartition"
    } |
    ForEach-Object {
    	Get-WmiObject -Query "ASSOCIATORS OF {Win32_DiskPartition.DeviceID=`"$($_.DeviceID)`"} WHERE AssocClass = Win32_LogicalDiskToPartition"
    }
}



<#

.SYNOPSIS
Obtain drive letters of USB drives.

.DESCRIPTION
Returns USB drive designators.

.INPUTS
None. You cannot pipe objects to Get-UsbDriveLetter.

.OUTPUTS
Array of string.

.NOTES
This function is part of the CleanCode toolbox
from http://cleancode.sourceforge.net/.

Since CleanCode 1.1.04.

.LINK
Get-UsbDriveCapacity
Get-UsbDriveInfo

#>

function Get-UsbDriveLetter {
[OutputType([string[]])]
param()

	Get-UsbDriveInfo | % { $_.DeviceID }
}



<#

.SYNOPSIS
Obtain capacities of USB drives.

.DESCRIPTION
Returns USB drive capacities.

.INPUTS
None. You cannot pipe objects to Get-UsbDriveCapacity.

.OUTPUTS
Array of UInt64.

.NOTES
This function is part of the CleanCode toolbox
from http://cleancode.sourceforge.net/.

Since CleanCode 1.1.04.

.LINK
Get-UsbDriveLetter
Get-UsbDriveInfo

#>

function Get-UsbDriveCapacity {
[OutputType([UInt64[]])]
param()

	Get-UsbDriveInfo | % { $_.Size }
}

Export-ModuleMember Get-UsbDriveInfo
Export-ModuleMember Get-UsbDriveLetter
Export-ModuleMember Get-UsbDriveCapacity
