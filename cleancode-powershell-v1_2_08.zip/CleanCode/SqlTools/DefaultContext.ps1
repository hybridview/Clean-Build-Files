#
# ==============================================================
# @ID       $Id: DefaultContext.ps1 1391 2013-05-31 03:00:02Z ms $
# @created  2012-11-01
# @project  http://cleancode.sourceforge.net/
# ==============================================================
#
# The official license for this file is shown next.
# Unofficially, consider this e-postcardware as well:
# if you find this module useful, let us know via e-mail, along with
# where in the world you are and (if applicable) your website address.
#
#
# ***** BEGIN LICENSE BLOCK *****
# Version: MPL 1.1
#
# The contents of this file are subject to the Mozilla Public License Version
# 1.1 (the "License"); you may not use this file except in compliance with
# the License. You may obtain a copy of the License at
# http://www.mozilla.org/MPL/
#
# Software distributed under the License is distributed on an "AS IS" basis,
# WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
# for the specific language governing rights and limitations under the
# License.
#
# The Original Code is part of the CleanCode toolbox.
#
# The Initial Developer of the Original Code is Michael Sorens.
# Portions created by the Initial Developer are Copyright (C) 2012
# the Initial Developer. All Rights Reserved.
#
# Contributor(s):
#
# ***** END LICENSE BLOCK *****
#

Set-StrictMode -Version Latest

<#  
.SYNOPSIS  
Infer values for server and database into reference variables.

.DESCRIPTION
Updates the supplied server instance and the database with inferred values if the supplied values are undefined.  It extends the notion of default context. That is, you do not actually have to be on the SQLSERVER: drive, only to have set the current location on that drive to a server and database path.

.INPUTS
None. You cannot pipe objects to Update-DBEnvironment.

.OUTPUTS
None. Produces no output.

.EXAMPLE
Update-DBEnvironment ([ref]$ServerInstance) ([ref]$Database)
If either of the supplied server or database values are $null or empty string, Get-DBPathInfo is used to attempt to infer a values for it, updating the supplied variables by reference.

.PARAMETER ServerInstance
Reference to a character string specifying the name of an instance of
the Database Engine. For default instances, only specify the computer name:
"MyComputer". For named instances, use the format "ComputerName\InstanceName".
If -ServerInstance is not specified Update-DBEnvironment attempts to infer it:
* If on a SQLSERVER: drive (or alias) and the path specifies the SQL folder,
Update-DBEnvironment uses the server and instance specified in the path.
* If not on a SQLSERVER: drive but the current location on your SQLSERVER:
drive specifies the SQL folder, Update-DBEnvironment uses the server and instance
specified in that path.

.PARAMETER Database
Reference to a character string specifying the name of a database.
Update-DBEnvironment connects to this database in the instance specified by -ServerInstance.
If -Database is not specified Update-DBEnvironment attempts to infer it:
* If on a SQLSERVER: drive (or alias) and the path specifies both the SQL folder
and a database name, Update-DBEnvironment uses the database specified in the path.
* If not on a SQLSERVER: drive but the current location on your SQLSERVER:
drive specifies both the SQL folder and a database name, Update-DBEnvironment uses
the database specified in that path.

.NOTES
This function is part of the CleanCode toolbox
from http://cleancode.sourceforge.net/.

Since CleanCode 1.1.05.
#>
function Update-DBEnvironment ([ref] $ServerInstance, [ref] $Database)
{
    if (!$ServerInstance.Value -or !$Database.Value) {
        ($sCandidate, $dCandidate) = Get-DBPathInfo
        if (!$ServerInstance.Value) { $ServerInstance.Value = $sCandidate }
        if (!$Database.Value) { $Database.Value = $dCandidate }
        if (!$ServerInstance.Value -or !$Database.Value) {
            throw "ServerInstance and Database must be specified"
        }
    }
}

<#  
.SYNOPSIS  
Infer values for server and database from SQLSERVER: drive.

.DESCRIPTION
Infers the server instance and database from the current location or, if not on a SQL Server drive, then from the default SQLSERVER: drive.  It extends the notion of default context. That is, you do not actually have to be on the SQLSERVER: drive, only to have set the current location on that drive to a server and database path.

.INPUTS
None. You cannot pipe objects to Get-DBPathInfo.

.OUTPUTS
Two-element array: first element contains server and instance name; second element contains database name.

.EXAMPLE
($serverCandidate, $dbCandidate) = Get-DBPathInfo
If your current location is *not* on a SQLSERVER: drive or alias, then the current location of the SQLSERVER: drive is used as the reference location.  If your current location includes the SQLSERVER: drive or an alias to some node on it, that is the reference location.  Either way, the reference location is examined to see if it contains a server and/or database.  If either server or db are both are not found $null is returned for that item.

.NOTES
This function is part of the CleanCode toolbox
from http://cleancode.sourceforge.net/.

Since CleanCode 1.1.05.
#>
function Get-DBPathInfo ()
{
    if ((Get-Location).Drive.Provider.Name -ne "SqlServer") {
        $sqlPath = Get-PSDrive | ? { $_.Name -eq "SQLSERVER" } | % { $_.Root + $_.CurrentLocation }
    }
    else {
        $sqlPath = (Get-Item .).PSPath
    }
    if ($sqlPath -match 'SQLSERVER:\\sql\\([^\\]*\\[^\\]*)\\Databases\\([^\\]*)')
    { return $Matches[1],$Matches[2] }
    elseif ($sqlPath -match 'SQLSERVER:\\sql\\([^\\]*\\[^\\]*)')
    { return $Matches[1],$null }
    else { return $null, $null }
}

<#  
.SYNOPSIS  
Executes Invoke-Sqlcmd while attempting to supply a default context.

.DESCRIPTION
This cmdlet is exactly equivalent to Invoke-Sqlcmd except that it extends the notion of default context. That is, you do not actually have to be on the SQLSERVER: drive, only to have set the current location on that drive to a server and database path.

.INPUTS
None. You cannot pipe objects to Invoke-InferredSqlcmd.

.OUTPUTS
Formatted table.

.EXAMPLE
Invoke-InferredSqlcmd -Query "SELECT GETDATE() AS TimeOfQuery;" -ServerInstance "MyComputer\MyInstance" -Database "MyDatabase"
Runs the basic T-SQL query on the explicitly provided server and database.

.EXAMPLE
Invoke-InferredSqlcmd -Query "SELECT GETDATE() AS TimeOfQuery;" 
Runs the basic T-SQL query using inferred values for ServerInstance and Database.

.PARAMETER ServerInstance
A character string specifying the name of an instance of
the Database Engine. For default instances, only specify the computer name:
"MyComputer". For named instances, use the format "ComputerName\InstanceName".
If -ServerInstance is not specified Invoke-InferredSqlcmd attempts to infer it:
* If on a SQLSERVER: drive (or alias) and the path specifies the SQL folder,
Invoke-InferredSqlcmd uses the server and instance specified in the path.
* If not on a SQLSERVER: drive but the current location on your SQLSERVER:
drive specifies the SQL folder, Invoke-InferredSqlcmd uses the server and instance
specified in that path.
This latter inference is the difference between Invoke-Sqlcmd
and Invoke-InferredSqlcmd.

.PARAMETER Database
A character string specifying the name of a database.
Invoke-InferredSqlcmd connects to this database in the instance specified by -ServerInstance.
If -Database is not specified Invoke-InferredSqlcmd attempts to infer it:
* If on a SQLSERVER: drive (or alias) and the path specifies both the SQL folder
and a database name, Invoke-InferredSqlcmd uses the database specified in the path.
* If not on a SQLSERVER: drive but the current location on your SQLSERVER:
drive specifies both the SQL folder and a database name, Invoke-InferredSqlcmd uses
the database specified in that path.
This latter inference is the difference between Invoke-Sqlcmd
and Invoke-InferredSqlcmd.

.PARAMETER EncryptConnection
See Invoke-Sqlcmd.

.PARAMETER Username
See Invoke-Sqlcmd.

.PARAMETER Password
See Invoke-Sqlcmd.

.PARAMETER Query
See Invoke-Sqlcmd.

.PARAMETER QueryTimeout
See Invoke-Sqlcmd.

.PARAMETER ConnectionTimeout
See Invoke-Sqlcmd.

.PARAMETER ErrorLevel
See Invoke-Sqlcmd.

.PARAMETER SeverityLevel
See Invoke-Sqlcmd.

.PARAMETER MaxCharLength
See Invoke-Sqlcmd.

.PARAMETER MaxBinaryLength
See Invoke-Sqlcmd.

.PARAMETER AbortOnError
See Invoke-Sqlcmd.

.PARAMETER DedicatedAdministratorConnection
See Invoke-Sqlcmd.

.PARAMETER DisableVariables
See Invoke-Sqlcmd.

.PARAMETER DisableCommands
See Invoke-Sqlcmd.

.PARAMETER HostName
See Invoke-Sqlcmd.

.PARAMETER NewPassword
See Invoke-Sqlcmd.

.PARAMETER Variable
See Invoke-Sqlcmd.

.PARAMETER InputFile
See Invoke-Sqlcmd.

.PARAMETER OutputSqlErrors
See Invoke-Sqlcmd.

.PARAMETER SuppressProviderContextWarning
See Invoke-Sqlcmd.

.PARAMETER IgnoreProviderContext
See Invoke-Sqlcmd.

.NOTES
This function is part of the CleanCode toolbox
from http://cleancode.sourceforge.net/.

Since CleanCode 1.1.05.
#>
function Invoke-InferredSqlcmd()
{
    [CmdletBinding()]  
    param(  
    [string]$ServerInstance,
    [string]$Database,
    [switch]$EncryptConnection,
    [string]$Username,
    [string]$Password,
    [Parameter(Position=0)] [string]$Query,
    [int]$QueryTimeout,
    [int]$ConnectionTimeout,
    [int]$ErrorLevel,
    [int]$SeverityLevel,
    [int]$MaxCharLength,
    [int]$MaxBinaryLength,
    [switch]$AbortOnError,
    [switch]$DedicatedAdministratorConnection,
    [switch]$DisableVariables,
    [switch]$DisableCommands,
    [string]$HostName,
    [string]$NewPassword,
    [string[]]$Variable,
    [string]$InputFile,
    [switch]$OutputSqlErrors,
    [switch]$SuppressProviderContextWarning,
    [switch]$IgnoreProviderContext
    )
    
    # Infer the DB server details and push values back into the param list
    Update-DBEnvironment ([ref]$ServerInstance) ([ref]$Database)
    $PSBoundParameters["ServerInstance"] = $ServerInstance
    $PSBoundParameters["Database"] = $Database

    # This is our raison d'etre so unless the caller has requested
    # to see the warning, suppress it.
    if (!$PSBoundParameters.ContainsKey("SuppressProviderContextWarning")) {
        $PSBoundParameters["SuppressProviderContextWarning"] = $true
    }
    
    Invoke-Sqlcmd @PSBoundParameters
}

Export-ModuleMember Get-DBPathInfo
Export-ModuleMember Update-DBEnvironment
Export-ModuleMember Invoke-InferredSqlcmd
