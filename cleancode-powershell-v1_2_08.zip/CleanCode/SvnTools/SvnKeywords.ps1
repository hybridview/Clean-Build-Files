#
# ==============================================================
# @ID       $Id: SvnKeywords.ps1 1395 2013-06-05 02:13:32Z ms $
# @created  2011-08-25
# @project  http://cleancode.sourceforge.net/
# ==============================================================
#
# The official license for this file is shown next.
# Unofficially, consider this e-postcardware as well:
# if you find this module useful, let us know via e-mail, along with
# where in the world you are and (if applicable) your website address.
#
#
# ***** BEGIN LICENSE BLOCK *****
# Version: MPL 1.1
#
# The contents of this file are subject to the Mozilla Public License Version
# 1.1 (the "License"); you may not use this file except in compliance with
# the License. You may obtain a copy of the License at
# http://www.mozilla.org/MPL/
#
# Software distributed under the License is distributed on an "AS IS" basis,
# WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
# for the specific language governing rights and limitations under the
# License.
#
# The Original Code is part of the CleanCode toolbox.
#
# The Initial Developer of the Original Code is Michael Sorens.
# Portions created by the Initial Developer are Copyright (C) 2011
# the Initial Developer. All Rights Reserved.
#
# Contributor(s):
#
# ***** END LICENSE BLOCK *****
#

Set-StrictMode -Version Latest
Import-Module CleanCode/FileTools

$svnConfigFile = "{0}\Subversion\config" -f $Env:APPDATA
$svnInstrumentedFilePattern = '\$(Author|Date|Id|Rev|URL)(: .*)?\$'
$svnKeywordProperty = "svn:keywords"

<#

.SYNOPSIS
Provides a variety of metrics on SVN keyword usage on your system.

.DESCRIPTION

For SVN keyword expansion to occur in a particular file, you need 3 things:
1. The file's extension (e.g. *.cs) must be activated in the Subversion configuration file.
2. The particular file must have the particular keywords enabled (via the svn:keywords property) that you wish to use.
3. The file must actually use the particular keyword place holders.

Measure-SvnKeywords generates a report on various aspects of those factors. The report consists of these section:

- Extensions enabled in configuration file
  Identifies the extensions in your Subversion configuration file
  that are activated. Only files in this list of extensions
  are candidates for keywords substitution.

- Summary of SVN files with keywords
  This is a summary of all your SVN files by extension that use
  SVN keywords; it reports a count of files for each extension.

- All files with keywords not enabled IN CONFIG FILE
  Unlike the other sections of the report, this section broadens the domain
  by ignoring the -Include parameter, if specified.
  This list tells you if you have any files that use keywords but those
  keywords are not enabled in the configuration file.

- SVN files without keywords
  This list enumerates all files not instrumented with keyword place holders,
  whether or not the files individually have keywords enabled.

- SVN files without keywords where keywords are enabled
  This list enumerates all files not instrumented with keyword place holders,
  yet having keywords enabled.

- SVN files with keywords to be enabled
  This list enumerates all files instrumented with keyword place holders,
  but where the keywords are not enabled.
  This particular list is the only list affected by the -EnableKeywords
  parameter. When you enable that switch, all items in this list have their
  svn:keywords property updated to allow keyword substitution.

.PARAMETER Exclude
Omits the specified items. The value of this parameter qualifies the
Path parameter.  Enter a path element or pattern, such as "*.txt".

.PARAMETER ExcludeTree
Excludes not just a matching item but also all its children as well.

.PARAMETER Include
Retrieves only the specified items. The value of this parameter qualifies
the Path parameter. Enter a path element or pattern, such as "*.txt".

The Include parameter is effective only when the command includes
the Recurse parameter or the path leads to the contents of a directory,
such as C:\Windows\*, where the wildcard character speci fies the contents
of the C:\Windows directory.

.PARAMETER Path
Specifies a path to one or more locations.
The default location is the current directory (.).

.PARAMETER Recurse
Gets the items in the specified locations and in all child items of
the locations. Recurse works only when the path points to a container
that has children, such as C:\Windows or C:\Windows\*, and not when it
points to items without children, such as C:\Windows\*.exe.

.PARAMETER EnableKeywords
When this switch is turned on, then for any file found that uses
SVN keywords but does not have keywords enabled for substitution, the
Svn properties of the file are changed to enable keyword substitution
by adding the svn:keywords property.

.INPUTS
System.String. You can pipe one or more path strings to Get-SvnInfo.

.OUTPUTS
Object. The type of object returned is determined by the provider with which it is used.

.EXAMPLE
PS> Measure-SvnKeywords -ExcludeTree Resources -Include *.cs,*.html -Exclude *.designer.cs,AssemblyInfo.cs,NamespaceDoc.cs -Recurse

Report statistics for Visual Studio projects, including all the C# source files but ignoring the designer-generated files and some bookkeeping files.  Also ignore entirely the Resources directory and its children. This reports the various SVN keyword metrics but does not change any.

.EXAMPLE
PS> Measure-SvnKeywords -ExcludeTree Resources -Include *.cs,*.html -Exclude *.designer.cs,AssemblyInfo.cs,NamespaceDoc.cs -Recurse -EnableKeywords

Same as the previous example, but for any file found that uses keywords but does not have keywords enabled for substitution, change the Svn properties of the file to enable keyword substitution (by adding the svn:keywords property).

.EXAMPLE
PS> Measure-SvnKeywords ...
This example just shows a portion of actual output.  The last section (Enabling keywords...) is only done if you explicitly ask for it, via the -EnableKeywords parameter.

    === Extensions enabled in configuration file:
    *.bat    => Author Date Id Rev URL
    *.cmd    => Author Date Id Rev URL
    *.cs     => Author Date Id Rev URL
    ...
    
    === Summary of SVN files with keywords:
    Extension=.cs   Occurrences= 92
    Extension=.html Occurrences=  3
    Extension=.java Occurrences= 53
    ...
    
    === All files with keywords not enabled IN CONFIG FILE:
    None
    
    === SVN files without keywords (13 files):
    Extension=.bat  Occurrences=  4
    	*****C:\code\cleancode-support\ftp-upload-script.bat
    	*****C:\code\dotnet\Projects\SqlDiffFramework\installer\package.bat
    	*****C:\code\js\ccwebpages\jsmake.bat
    	*****C:\code\js\validate\jsmake.bat
    Extension=.cs   Occurrences=  3
    	*****SqlDiffFramework\SqlDiffFramework\OptionsPanels\DifferencePanel.cs
    	*****SqlDiffFramework\SqlDiffFramework\OptionsPanels\GeneralPanel.cs
    	*****SqlDiffFramework\SqlDiffFramework\Program.cs
    Extension=.html Occurrences=  3
    	*****C:\code\powershell\CleanCode\Assertion\module_overview.html
    	*****C:\code\powershell\CleanCode\IniFile\module_overview.html
    	*****C:\code\powershell\CleanCode\namespace_overview.html
    Extension=.pl   Occurrences=  1
    	*****C:\code\cleancode-support\pscaption.pl
    Extension=.ps1  Occurrences=  2
    	*****C:\code\powershell\scripts\AnalyzeMySvnKeywords.ps1
    	*****C:\code\powershell\scripts\GenerateCleanCodeAPI.ps1
    
    === SVN files without keywords where keywords are enabled (6 files):
    Extension=.cs   Occurrences=  3
    	*****SqlDiffFramework\SqlDiffFramework\OptionsPanels\DifferencePanel.cs
    	*****SqlDiffFramework\SqlDiffFramework\OptionsPanels\GeneralPanel.cs
    	*****SqlDiffFramework\SqlDiffFramework\Program.cs
    Extension=.pl   Occurrences=  1
    	*****C:\code\cleancode-support\pscaption.pl
    Extension=.ps1  Occurrences=  2
    	*****C:\code\powershell\scripts\AnalyzeMySvnKeywords.ps1
    	*****C:\code\powershell\scripts\GenerateCleanCodeAPI.ps1
    
    === SVN files with keywords to be enabled (3 files):
    Extension=.cs   Occurrences=  2
    	*****CleanCode\CleanCode\Diagnostics\EnumerableDebugger.cs
    	*****CleanCode\GeneralComponents\Controls\ComboBoxWithTooltip.cs
    Extension=.ps1  Occurrences=  1
    	*****C:\code\powershell\CleanCode\SvnTools\SvnKeywords.ps1
    
    === Enabling keywords on files containing keywords:
    property 'svn:keywords' set on 'CleanCode\Diagnostics\EnumerableDebugger.cs'
    property 'svn:keywords' set on 'CleanCode\GeneralComponents\Controls\ComboBoxWithTooltip.cs'
    property 'svn:keywords' set on 'CleanCode\SvnTools\SvnKeywords.ps1'

.LINK
Get-EnhancedChildItem
.LINK
Get-SvnInfo
.LINK
Get-SvnLog
.LINK
[TortoiseSVN and Subversion Cookbook Part 5: Instrumenting Files with Version Information] (http://www.simple-talk.com/dotnet/.net-framework/tortoisesvn-and-subversion-cookbook-part-5-instrumenting-files-with-version-information/)
.LINK
[svn keyword substitution] (http://svnbook.red-bean.com/en/1.7/svn.advanced.props.special.keywords.html)
.LINK
[svn command reference] (http://svnbook.red-bean.com/en/1.7/svn.ref.html)
.LINK
[The Subversion Book] (http://svnbook.red-bean.com/)

.NOTES
This function is part of the CleanCode toolbox
from http://cleancode.sourceforge.net/.

Since CleanCode 1.1.01.

#>

function Measure-SvnKeywords(
	[Parameter(Position=0, ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true)]
	[SupportsWildcards()]
	[string[]]$Path,

	[SupportsWildcards()]
	[string[]]${Include},

	[SupportsWildcards()]
	[string[]]${Exclude},

	[SupportsWildcards()]
	[string[]]${ExcludeTree} = @(),

	[switch]${Recurse},

	[switch]${EnableKeywords}
)
{
	$totalSteps = 8
	$script:stepCounter = 0
	$PSBoundParameters.Remove("EnableKeywords") | Out-Null

	Progress "SVN files"
	$svnfiles = Get-EnhancedChildItem -NoContainersOnly @PSBoundParameters -Svn
	if (!$svnfiles) { Write-Warning "No SVN files found."; return }

	Progress "All files"
	# For a broader perspective, omit the Include list here...
	[Void]$PSBoundParameters.Remove("Include")
	$allFiles = Get-EnhancedChildItem -NoContainersOnly @PSBoundParameters

	$extInConfig = GetExtensionsEnabledInConfig
	Progress "Files with keywords not enabled in config"
	$filesWithKeywordsNotEnabledInConfig = GetExtensionsUsedButNotInConfig $extInConfig $allFiles

	Progress "SVN files with keywords"
	$svnFilesWithKeywords = $svnfiles |
		? {  (Select-String -Path $_.FullName -Pattern $svnInstrumentedFilePattern -Quiet ) }

	Progress "SVN files lacking keywords"
	$svnFilesLackingKeywords = $svnfiles |
		? { !(Select-String -Path $_.FullName -Pattern $svnInstrumentedFilePattern -Quiet ) }

	if ($svnFilesWithKeywords) {
		Progress "Summarize extensions for files with keywords"
		$summarySvnExtensionsWithKeywords =
			$svnFilesWithKeywords |
			? { $_.Extension } |
			Group-Object Extension |
			Sort Name |
			% { "Extension={0,-5} Occurrences={1,3}" -f $_.Name, $_.Count }
		Progress "SVN files with disabled keywords"
		$svnFilesWithKeywordsButDisabled = $svnFilesWithKeywords |
			? { ! ( & svn propget $svnKeywordProperty $_.FullName ) }
	}
	else {
		Progress "Summarize extensions for files with keywords"
		$summarySvnExtensionsWithKeywords = $null
		Progress "SVN files with disabled keywords"
		$svnFilesWithKeywordsButDisabled = $null
	}

	Progress "SVN enabled files lacking keywords"
	if ($svnFilesLackingKeywords) {
		$svnFilesLackingKeywordsButEnabled = $svnFilesLackingKeywords |
			? { & svn propget $svnKeywordProperty $_.FullName }
	}
	else {
		$svnFilesLackingKeywordsButEnabled = $null
	}
	Progress "processing complete"

	Output-SimpleList $extInConfig                      "Extensions enabled in configuration file"
	Output-SimpleList $summarySvnExtensionsWithKeywords "Summary of SVN files with keywords"
	Output-ByGroup $filesWithKeywordsNotEnabledInConfig "All files with keywords not enabled IN CONFIG FILE"
	Output-ByGroup $svnFilesLackingKeywords             "SVN files without keywords"
	Output-ByGroup $svnFilesLackingKeywordsButEnabled   "SVN files without keywords where keywords are enabled"
	Output-ByGroup $svnFilesWithKeywordsButDisabled     "SVN files with keywords to be enabled"

	if ($EnableKeywords)
	{
		if ($svnFilesWithKeywordsButDisabled)
		{
			DisplayTitle "Enabling keywords on files containing keywords"
			foreach ($obj in $svnFilesWithKeywordsButDisabled)
			{
				#write-host "Updating $obj..."
				& svn propset svn:keywords "Author Id HeadURL Revision Date" $obj
			}
		}
		else
		{ Write-Warning "No candidate files to update." }
	}
}

function Progress($activity)
{
	$percent = ($script:stepCounter++ * 100/ $totalSteps)
	write-progress -id 1 -activity "Running..." -status $activity -percentComplete $percent
}

function GetExtensionsEnabledInConfig()
{
	$configHash = Get-IniFile ($svnConfigFile)
	$keywordHash = @{}
	# Now parse a subversion config value, e.g. "svn:keywords=Author Date Id Rev URL;svn:eol-style=native"
	$configHash["auto-props"].GetEnumerator() | % {
		$keywordItem = $_.value.split(";") | Where { $_.StartsWith($svnKeywordProperty) }
		if ($keywordItem) { $keywordHash[$_.key] = $keywordItem }
		#Write-Host ("{0} ==> {1} [{2}]" -f $_.key, $_.value, $keywordItem)
	}
	$keywordHash.Keys | Sort | % { "{0,-8} => {1}" -f $_, $keywordHash[$_].split("=")[1] }
}

function GetExtensionsUsedButNotInConfig($extInConfig, $allFiles)
{
	# NB: this looks at all files, not just SVN files
	$allFilesWithKeywords = $allFiles |
		? { (Select-String -Path $_.FullName -Pattern $svnInstrumentedFilePattern -Quiet ) }
	if (!$allFilesWithKeywords) { return $null }

	$extWithKeywordsFiltered = $allFilesWithKeywords | ? { $_.Extension } |
		? { ! ( $extInConfig -ccontains ("*" + $_.Extension) ) }
}

function Output-SimpleList($list, $title)
{
	DisplayTitle $title
	if (!$list) { return "None" }
	$list | %{ "{0}" -f $_ }
}

function Output-ByGroup($list, $title)
{
	DisplayTitle (DecorateWithFileCount $list $title)
	if (!$list) { return "None" }
	$list | Group-Object Extension | Sort Name | %{
		"Extension={0,-5} Occurrences={1,3}" -f $_.Name, $_.Count
		$_.Group | % { "    *****" + $_.FullName }
		"" # include vertical space after each group
	}
}

function DecorateWithFileCount($list, $title)
{
	if ($list -is [array]) { $count = "{0} files" -f $list.Count }
	else { $count = "1 file" }
	if ($list) { $title = "{0} ({1})" -f $title, $count }
	$title
}

function DisplayTitle($title)
{
	write-host -BackgroundColor DarkGray ("`n`n=== {0}:`n" -f $title)
}

Export-ModuleMember Measure-SvnKeywords
