##########################################################################
# Source: http://gallery.technet.microsoft.com/scriptcenter/2fdeaf8d-b164-411c-9483-99413d6053ae
# (obsoletes the version at http://poshcode.org/2943)
# Author: Chad Miller
# Date:   2010.10.04
##########################################################################

Set-StrictMode -Version Latest

<# 
.SYNOPSIS 
Writes data to a SQL Server table.

.DESCRIPTION 
Writes data only to SQL Server tables.  However, the data source is not limited to SQL Server; any data source can be used, as long as the data can be loaded to a DataTable instance or read with an IDataReader instance. (Based on Chad Miller's original work--see Links section.)

.INPUTS 
None. You cannot pipe objects to Write-DataTable.

.OUTPUTS 
None. Produces no output.

.PARAMETER ServerInstance
Character string or SMO server object specifying the name of an instance of
the Database Engine. For default instances, only specify the computer name:
"MyComputer". For named instances, use the format "ComputerName\InstanceName".
If -ServerInstance is not specified Write-DataTable attempts to infer it:
* If on a SQLSERVER: drive (or alias) and the path specifies the SQL folder,
Write-DataTable uses the server and instance specified in the path.
* If not on a SQLSERVER: drive but the current location on your SQLSERVER:
drive specifies the SQL folder, Write-DataTable uses the server and instance
specified in that path.

.PARAMETER Database
A character string specifying the name of a database. Write-DataTable connects to
this database in the instance specified by -ServerInstance.
If -Database is not specified Write-DataTable attempts to infer it:
* If on a SQLSERVER: drive (or alias) and the path specifies both the SQL folder
and a database name, Write-DataTable uses the database specified in the path.
* If not on a SQLSERVER: drive but the current location on your SQLSERVER:
drive specifies both the SQL folder and a database name, Write-DataTable uses
the database specified in that path.

.PARAMETER TableName
Name of the table to create on the SQL Server instance.

.PARAMETER Data
A System.Data.DataTable containing the data to write to the SQL table.

.PARAMETER Username
Specifies the login ID for making a SQL Server Authentication connection
to an instance of the Database Engine. The password must be specified
using -Password. If -Username and -Password are not specified, Write-DataTable
attempts a Windows Authentication connection using the Windows account running
the PowerShell session.  When possible, use Windows Authentication.  

.PARAMETER Password
Specifies the password for the SQL Server Authentication login ID specified
in -Username. Passwords are case-sensitive.
When possible, use Windows Authentication.
SECURITY NOTE: If you type -Password followed by your password, the password
is visible to anyone who can see your monitor. If you use -Password in
a .ps1 script, anyone reading the script file will see your password.
Assign appropriate permissions to the file to allow only authorized users
to read the file.

.PARAMETER BatchSize
Number of rows to send to server at one time (set to 0 to send all rows).
This parameter maps to the same named parameter in the .NET class SqlBulkCopy. 

.PARAMETER QueryTimeout
Number of seconds for batch to complete before failing. Though not advised,
you can use 0 to indicate no limit.
This parameter maps to the BulkCopyTimeout parameter in the .NET class SqlBulkCopy. 

.PARAMETER ConnectionTimeout
Number of seconds for connection to complete before failing. Though not advised,
you can use 0 to indicate no limit.

.EXAMPLE 
$dt = Invoke-Sqlcmd -ServerInstance "Z003\R2" -Database pubs "select *  from authors"; Write-DataTable -ServerInstance "Z003\R2" -Database pubscopy -TableName authors -Data $dt 
This example loads a variable dt of type DataTable from query and write the datatable to another database.  This requires the target table to already exist.  Use Add-SqlTable to create the table if necessary.

.NOTES 
Write-DataTable uses the SqlBulkCopy class see links for additional information on this class. 
Version History 
v1.0   - Chad Miller - Initial release 
v1.1   - Chad Miller - Fixed error message 

.LINK 
[Write-DataTable original by Chad Miller](http://gallery.technet.microsoft.com/scriptcenter/2fdeaf8d-b164-411c-9483-99413d6053ae)
.LINK
Out-DataTable
.LINK
Add-SqlTable
.LINK
Out-SqlTable
.LINK
Update-DBEnvironment
.LINK
[SqlBulkCopy](http://msdn.microsoft.com/en-us/library/30c3y597.aspx)

#> 
function Write-DataTable 
{ 
    [CmdletBinding()] 
    param( 
    [Parameter(Position=0, Mandatory=$false)] [string]$ServerInstance, 
    [Parameter(Position=1, Mandatory=$false)] [string]$Database, 
    [Parameter(Position=2, Mandatory=$true)] [string]$TableName, 
    [Parameter(Position=3, Mandatory=$true)] $Data, 
    [Parameter(Position=4, Mandatory=$false)] [string]$Username, 
    [Parameter(Position=5, Mandatory=$false)] [string]$Password, 
    [Parameter(Position=6, Mandatory=$false)] [Int32]$BatchSize=0, # same as SqlBulkCopy default
    [Parameter(Position=7, Mandatory=$false)] [Int32]$QueryTimeout=30, # same as SqlBulkCopy default
    [Parameter(Position=8, Mandatory=$false)] [Int32]$ConnectionTimeout=15 # same as SqlConnection default 
    ) 

    # 2012.10.19 msorens: Removed superfluous SQLConnection object.
    # 2012.10.19 msorens: Allow ServerInstance or Database to be inferred.
    Update-DBEnvironment ([ref]$ServerInstance) ([ref]$Database)
  
    if ($Username) 
    { $ConnectionString = "Server={0};Database={1};User ID={2};Password={3};Trusted_Connection=False;Connect Timeout={4}" -f $ServerInstance,$Database,$Username,$Password,$ConnectionTimeout } 
    else 
    { $ConnectionString = "Server={0};Database={1};Integrated Security=True;Connect Timeout={2}" -f $ServerInstance,$Database,$ConnectionTimeout } 
  
    try 
    { 
        $bulkCopy = new-object ("Data.SqlClient.SqlBulkCopy") $connectionString 
        $bulkCopy.DestinationTableName = $tableName 
        $bulkCopy.BatchSize = $BatchSize 
        $bulkCopy.BulkCopyTimeout = $QueryTimeOut

        # 2012.11.15 msorens: Allow for identity columns to exist
        $tableObj = Get-Item SQLSERVER:\sql\$ServerInstance\Databases\$Database\tables\dbo.$tableName
        $identCount = @($tableObj.Columns | ? { $_.Identity}).Count
        if ($identCount -gt 0) {
            foreach ($col in $Data.Columns) {
                $colmap = new-object ("Data.SqlClient.SqlBulkCopyColumnMapping") $col.ColumnName, $col.ColumnName
                [Void] $bulkCopy.ColumnMappings.Add($colmap)
            }
        }

        $bulkCopy.WriteToServer($Data) 
    }
    catch 
    { 
        $ex = $_.Exception 
        Write-Error "$ex.Message" 
        continue 
    } 
 
} #Write-DataTable

Export-ModuleMember Write-DataTable
