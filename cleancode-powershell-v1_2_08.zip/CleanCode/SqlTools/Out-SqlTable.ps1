#
# ==============================================================
# @ID       $Id: Out-SqlTable.ps1 1395 2013-06-05 02:13:32Z ms $
# @created  2012-11-01
# @project  http://cleancode.sourceforge.net/
# ==============================================================
#
# The official license for this file is shown next.
# Unofficially, consider this e-postcardware as well:
# if you find this module useful, let us know via e-mail, along with
# where in the world you are and (if applicable) your website address.
#
#
# ***** BEGIN LICENSE BLOCK *****
# Version: MPL 1.1
#
# The contents of this file are subject to the Mozilla Public License Version
# 1.1 (the "License"); you may not use this file except in compliance with
# the License. You may obtain a copy of the License at
# http://www.mozilla.org/MPL/
#
# Software distributed under the License is distributed on an "AS IS" basis,
# WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
# for the specific language governing rights and limitations under the
# License.
#
# The Original Code is part of the CleanCode toolbox.
#
# The Initial Developer of the Original Code is Michael Sorens.
# Portions created by the Initial Developer are Copyright (C) 2012
# the Initial Developer. All Rights Reserved.
#
# Contributor(s):
#
# ***** END LICENSE BLOCK *****
#

Set-StrictMode -Version Latest

<#  
.SYNOPSIS  
Creates a SQL Server table from Powershell objects.

.DESCRIPTION 
Out-SqlTable  is simply a composition of Out-DataTable, Add-SqlTable, and Write-DataTable.

.PARAMETER TableName
Name of the table to create on the SQL Server instance.

.PARAMETER ServerInstance
Character string or SMO server object specifying the name of an instance of
the Database Engine. For default instances, only specify the computer name:
"MyComputer". For named instances, use the format "ComputerName\InstanceName".
If -ServerInstance is not specified Out-SqlTable attempts to infer it:
* If on a SQLSERVER: drive (or alias) and the path specifies the SQL folder,
Out-SqlTable uses the server and instance specified in the path.
* If not on a SQLSERVER: drive but the current location on your SQLSERVER:
drive specifies the SQL folder, Out-SqlTable uses the server and instance
specified in that path.

.PARAMETER Database
A character string specifying the name of a database. Out-SqlTable connects to
this database in the instance specified by -ServerInstance.
If -Database is not specified Out-SqlTable attempts to infer it:
* If on a SQLSERVER: drive (or alias) and the path specifies both the SQL folder
and a database name, Out-SqlTable uses the database specified in the path.
* If not on a SQLSERVER: drive but the current location on your SQLSERVER:
drive specifies both the SQL folder and a database name, Out-SqlTable uses
the database specified in that path.

.PARAMETER Username
Specifies the login ID for making a SQL Server Authentication connection
to an instance of the Database Engine. The password must be specified
using -Password. If -Username and -Password are not specified, Out-SqlTable
attempts a Windows Authentication connection using the Windows account running
the PowerShell session.  When possible, use Windows Authentication.  

.PARAMETER Password
Specifies the password for the SQL Server Authentication login ID specified
in -Username. Passwords are case-sensitive.
When possible, use Windows Authentication.
SECURITY NOTE: If you type -Password followed by your password, the password
is visible to anyone who can see your monitor. If you use -Password in
a .ps1 script, anyone reading the script file will see your password.
Assign appropriate permissions to the file to allow only authorized users
to read the file.

.PARAMETER MaxLength
Capacity for VarChar and VarBinary columns (limited to 8000 maximum).
Any data longer than this defined value will be truncated when inserted.

.PARAMETER RowId
Serving as both a switch and a column name, specifying -RowId adds
an identity column to the table with the value supplied as the column name.

.PARAMETER DropExisting
If enabled, Out-SqlTable will check whether the table exists before
attempting to create it. If it does exist, it is first dropped.
Attempting to use Out-SqlTable without this switch when the table already
exists generates an error.

.PARAMETER BatchSize
Number of rows to send to server at one time (set to 0 to send all rows).
This parameter maps to the same named parameter in the .NET class SqlBulkCopy. 

.PARAMETER QueryTimeout
Number of seconds for batch to complete before failing. Though not advised,
you can use 0 to indicate no limit.
This parameter maps to the BulkCopyTimeout parameter in the .NET class SqlBulkCopy. 

.PARAMETER ConnectionTimeout
Number of seconds for connection to complete before failing. Though not advised,
you can use 0 to indicate no limit.

.INPUTS
Object. Any object can be piped to Out-SqlTable.

.OUTPUTS
None. Produces no output.

.EXAMPLE  
Get-Process | select ProcessName, Handle | Out-SqlTable -TableName "processes"
Puts selected columnar output from Get-Process into a table in the current database, where the "current database" is specifed by the current location on a SQLSERVER: drive.  This is equivalent to these three consecutive commands:
    $dt = Get-Process | select ProcessName, Handle | Out-DataTable
    Add-SqlTable -TableName "processes" -DataTable $dt
    Write-DataTable -TableName "processes" -Data $dt

.EXAMPLE  
ps | select ProcessName, Handle | Out-SqlTable -TableName "processes" -DropExisting -RowId "MyId"
Puts selected columnar output from Get-Process into a table in the current database, dropping the table first if it exists, and adding an identity column "MyId".

.EXAMPLE  
Get-SvnLog . | Out-SqlTable -TableName "svndata" -MaxLength 3000
Puts the output of the CleanCode Get-SvnLog cmdlet into a database table, allowing string fields to be up to 3000 characters rather than the default 1000.  This is useful primarily for the msg property of Subversion data.

.NOTES
This function is part of the CleanCode toolbox
from http://cleancode.sourceforge.net/.

Since CleanCode 1.1.05.

.LINK
Out-DataTable
.LINK
Add-SqlTable
.LINK
Write-DataTable
.LINK
Update-DBEnvironment
.LINK
[SqlBulkCopy](http://msdn.microsoft.com/en-us/library/30c3y597.aspx)

#>  
function Out-SqlTable
{
[CmdletBinding()] 
param(
	[Parameter(Position=0, Mandatory=$true, ValueFromPipeline=$true)] [PSObject[]]$InputObject,
	[Parameter(Position=1, Mandatory=$true)] [string]$TableName,
    [Parameter(Mandatory=$false)] [string]$ServerInstance,  
    [Parameter(Mandatory=$false)] [string]$Database,  
    [Parameter(Mandatory=$false)] [string]$Username,  
    [Parameter(Mandatory=$false)] [string]$Password,  
    [Parameter(Mandatory=$false)] [Int32]$MaxLength, 
    [Parameter(Mandatory=$false)] [string]$RowId,  
    [Parameter(Mandatory=$false)] [switch]$DropExisting,
    [Parameter(Mandatory=$false)] [Int32]$BatchSize,
    [Parameter(Mandatory=$false)] [Int32]$QueryTimeout,
    [Parameter(Mandatory=$false)] [Int32]$ConnectionTimeout
)
 
End {
	Update-DBEnvironment ([ref]$ServerInstance) ([ref]$Database)

	$dataTable = $input | Out-DataTable

	$AddParams = @{"ServerInstance"=$ServerInstance; "Database"=$Database; "DataTable"=$dataTable }
	$PSBoundParameters.Keys | 
		? { "TableName","Username","Password","MaxLength","RowId","DropExisting" -contains $_ } |
		% { $AddParams[$_] = $PSBoundParameters[$_] }
	Add-SqlTable @AddParams

	$WriteParams = @{"ServerInstance"=$ServerInstance; "Database"=$Database; "Data"=$dataTable }
	$PSBoundParameters.Keys | 
		? { "TableName","Username","Password","BatchSize","QueryTimeout","ConnectionTimeout" -contains $_ } |
		% { $WriteParams[$_] = $PSBoundParameters[$_] }
	Write-DataTable @WriteParams
	}
}

Export-ModuleMember Out-SqlTable
