#
# ==============================================================
# @ID       $Id: Assertion.psm1 1560 2015-12-16 19:46:13Z ms $
# @created  2011-06-01
# @project  http://cleancode.sourceforge.net/
# ==============================================================
#
# The official license for this file is shown next.
# Unofficially, consider this e-postcardware as well:
# if you find this module useful, let us know via e-mail, along with
# where in the world you are and (if applicable) your website address.
#
#
# ***** BEGIN LICENSE BLOCK *****
# Version: MPL 1.1
#
# The contents of this file are subject to the Mozilla Public License Version
# 1.1 (the "License"); you may not use this file except in compliance with
# the License. You may obtain a copy of the License at
# http://www.mozilla.org/MPL/
#
# Software distributed under the License is distributed on an "AS IS" basis,
# WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
# for the specific language governing rights and limitations under the
# License.
#
# The Original Code is part of the CleanCode toolbox.
#
# The Initial Developer of the Original Code is Michael Sorens.
# Portions created by the Initial Developer are Copyright (C) 2011
# the Initial Developer. All Rights Reserved.
#
# Contributor(s):
#
# ***** END LICENSE BLOCK *****
#

Set-StrictMode -Version Latest

$displayLenMax = 50
$ellipsis = "..."
$passColor = "Green"
$failColor = "Red"
$abortOnError = $false
$exprOpen = "<<"
$exprClose= ">>"
$countPass = 0
$countFail = 0

<#

.SYNOPSIS
Adjusts the column width of the echoed input express to Assert-Expression.

.DESCRIPTION
Normally, Assert-Expression echoes up to 50 characters of its input expression, then reports failure details.  Set-MaxExpressionDisplayLength lets you change that first column width.

.PARAMETER limit
Number of characters of the input expression to echo.

.INPUTS
None. You cannot pipe objects to Set-MaxExpressionDisplayLength.

.OUTPUTS
None. Set-MaxExpressionDisplayLength does not generate any output.

.EXAMPLE
PS> Set-MaxExpressionDisplayLength 25
Reduce the first column width to 25.

.EXAMPLE
PS> Set-MaxExpressionDisplayLength
Reset the first column width to the default (50).

.LINK
Assert-Expression

.NOTES
This function is part of the CleanCode toolbox
from http://cleancode.sourceforge.net/.

Since CleanCode 1.1.01.

#>

function Set-MaxExpressionDisplayLength([int]$limit = 50)
{
	$script:displayLenMax = $limit
}

<#

.SYNOPSIS
Adjusts Assert-Expression to throw an exception on a failure rather than to just report the failure.

.DESCRIPTION
Normally, Assert-Expression simply reports test results to the console.  Enabling abort-on-error with the Set-AbortOnError function modifies the behavior to throw exceptions on each failure instead.

.PARAMETER state
A Boolean indicating to enable or disable abort-on-error.

.INPUTS
None. You cannot pipe objects to Set-AbortOnError.

.OUTPUTS
None. Set-AbortOnError does not generate any output.

.EXAMPLE
PS> Set-AbortOnError $true
Enables abort-on-error.

.LINK
Assert-Expression

.NOTES
This function is part of the CleanCode toolbox
from http://cleancode.sourceforge.net/.

Since CleanCode 1.1.01.

#>

function Set-AbortOnError([bool]$state)
{
	$script:abortOnError = $state
}


<#

.SYNOPSIS
Reports the previously collected pass/fail statistics (and resets the counters).

.INPUTS
None. You cannot pipe objects to Get-AssertCounts.

.OUTPUTS
String in the format "Pass: mm, Fail: nn"

.EXAMPLE
PS> Get-AssertCounts
Pass: 13, Fail: 9 (assuming you have run 22 tests)

.NOTES
This function is part of the CleanCode toolbox
from http://cleancode.sourceforge.net/.

Since CleanCode 1.1.01.

#>

function Get-AssertCounts
{
	"Pass: {0}, Fail: {1}" -f $countPass, $countFail
	$script:countPass = 0
	$script:countFail = 0
}

<#

.SYNOPSIS
Tests a PowerShell expression against expected values and provides color-coded results.

.DESCRIPTION
Assert-Expression lets you validate assertions, taking advantage of PowerShell's capability to evaluate code dynamically.  Supply an expression as a string along with an expected result.  The string is evaluated with PowerShell's Invoke-Expression cmdlet and the result compared to your expected result.

Assert-Expression reports its results to the console.  The expression is displayed along with a "pass" (green) or "fail" (red).  If the test fails, the actual and expected values are both displayed.  The actual result and the expected result may each be either a scalar or an array. If either is an array, the entire array is displayed and those values that mismatch are higlighted in red.  Note that arrays are always considered ordered lists, not sets.  Thus if you expect (1, 2) but you get (2, 1), both elements of the array are highlighted as mismatches.

Normally, Assert-Expression reports and returns but you can also make it throw an exception on a failure via the Set-AbortOnError function.

The failed results are aligned after the input expression on the same line.  Use the Set-MaxExpressionDisplayLength to adjust how much of the input expression to display.

Use Get-AssertCounts at the end to get a count of passed and failed tests.

.PARAMETER expression
A string representing a valid PowerShell expression or an array of values.
If you provide a string, use care when selecting either single quotes
or double quotes to delimit the expression string
to prevent or allow variable interpolation.
Thus, passing "f 25 $null -6" is quite different from 'f 25 $null -6'.
If you provide an array, its elements are considered the list of
actual values; no evaluation is performed.

.PARAMETER expected
A scalar or array of values you expect the expression to return.

.INPUTS
None. You cannot pipe objects to Assert-Expression.

.OUTPUTS
None. Assert-Expression does not generate any output.

.EXAMPLE
PS> Assert-Expression '(2 + 5)' 7
* Result: PASS
* Reason: Sum of the two values is 7.

.EXAMPLE
PS> Assert-Expression '[Math]::Min(-5,-9)' -9
* Result: PASS
* Reason: Minimum of the two values is -9.

.EXAMPLE
PS> Assert-Expression '"xyz".substring(1,0)' ""
* Result: PASS
* Reason: Expression evaluates to an empty string.

.EXAMPLE
PS> Assert-Expression '"[abc]","[def]","[ghi]"' "[abc]","[def]","[ghi]"
* Result: PASS
* Reason: Expression evaluation matches the expected result item for item.

.EXAMPLE
PS> Assert-Expression '"[abc]"' "[abc]","[def]","[ghi]"
* Result: FAIL
* Reason: Expression evaluation returns [abc] while expecting a 3-item array.  The second and third items are highlighted as erroneous.

.EXAMPLE
PS> Assert-Expression '"[ghi]"' "[abc]","[def]","[ghi]"
* Result: FAIL
* Reason: Expression evaluation returns [ghi] while expecting a 3-item array.  All three items are highlighted as erroneous because none of them match positionally. That is, the first item is supposed to be [abc], not [ghi], so that is a mismatch. There are no more items returned from the expression, so the leftover items mismatch.

.EXAMPLE
PS> Assert-Expression '"[abc]","[def]","[ghi]"' "[abc]"
* Result: FAIL
* Reason: Expression evaluation returns three items while expecting just one.  The second and third items are highlighted as erroneous.

.EXAMPLE
PS> New-Module -scriptblock {function Double($count) { $count * 2}} | Out-Null; Assert-Expression 'Double(25)' 50; $global:myNum = 99; Assert-Expression 'Double($myNum)' 198
* Result: PASS
* Reason: This example shows how to handle functions that may be in a library.  As the first Assert-Expression shows, constant arguments work just fine.  But in order to pass a variable from the current script as in the second part of the example, you must give that variable global scope, otherwise it will generate a runtime error flagging $myNum as undefined.

.LINK
Set-AbortOnError
.LINK
Set-MaxExpressionDisplayLength
.LINK
Get-AssertCounts

.NOTES
This function is part of the CleanCode toolbox
from http://cleancode.sourceforge.net/.

Since CleanCode 1.1.01.

#>

function Assert-Expression($actual, $expected, $label)
{
	# Allow for scalar/array mismatch
	if (($expected -isnot [array]) -and ($actual -is [array])) {
		$expected = ,$expected # convert to array
	}
	if (($actual -isnot [array]) -and ($expected -is [array])) {
		$actual = ,$actual # convert to array
	}

	if ($expected -is [array]) {
		$errMarks = @()
		$minCount = [Math]::Min($actual.count, $expected.count)
		$maxCount = [Math]::Max($actual.count, $expected.count)

		# Check corresponding items
		if ($minCount -gt 0) {
			0..($minCount-1) | % {
				if ($expected[$_] -ne $actual[$_]) { $errMarks += $_ }
			}
		}

		# Add excess items (i.e. arrays of different length)
		if ($minCount -lt $maxCount) {
			$minCount..($maxCount-1) | % { $errMarks += $_ }
		}

		# Report
		if ($errMarks.Count -gt 0) {
			ReportFail $label $expected $actual $errMarks
			if ($abortOnError) { throw "assertion error on these elements:" + $errMarks }
		}
		else { ReportPass $label $actual }
	}
	else {
		if ($expected -eq $actual) { ReportPass $label $actual }
		else {
			ReportFail $label $expected $actual
			if ($abortOnError) { throw ("assertion error: {0} vs. {1}" -f $expected, $actual) }
		}
	}
}

# # # # # # # # # Support functions # # # # # # # #

function ReportPass($label, $actual)
{
	if ($label -eq $null) { $label = $actual } else { $label += ": $actual" }
	Write-Host -Foreground $passColor "PASS: " -NoNewline
	Write-Host (Constrain $label)
	$script:countPass += 1
}

function ReportFail($label, $expected, $actual, $errMarks)
{
	if ($label -eq $null) { $label = $actual }
	Write-Host -Foreground $failColor "FAIL: " -NoNewline
	# This format string aligns the following 'Expected' labels horizontally.
	$fmtString = "{0,-" + ($displayLenMax + $exprOpen.length + $exprClose.length) + "}"
	Write-Host ($fmtString -f (Constrain $label)) -NoNewline
	Write-Host " Expected=" -NoNewline
	OutputWithDelimiters $expected $errMarks
	Write-Host ", Actual=" -NoNewline
	OutputWithDelimiters $actual $errMarks
	Write-Host
	$script:countFail += 1
}

function OutputWithDelimiters($list, $errMarks)
{
	Write-Host "'" -NoNewline
	if ($errMarks -is [array] -and $list -is [array])
	{
		if ($list.count -gt 0)
		{
		0..($list.count - 1) | % {
			if ($errMarks -contains $_) {
				Write-Host -Foreground $failColor (ShowExplicitEmpties $list[$_]) -NoNewline }
			else { Write-Host (ShowExplicitEmpties $list[$_]) -NoNewline }
			if ($_ -lt ($list.count - 1)) { Write-Host ","  -NoNewline }
		}
		}
		else { Write-Host -Foreground $failColor (ShowExplicitEmpties $list) -NoNewline
		}
	}
	else { Write-Host -Foreground $failColor (ShowExplicitEmpties $list) -NoNewline }
	Write-Host "'" -NoNewline
}

function ShowExplicitEmpties($item)
{
	if ($item -eq $null) { '$null' }
	elseif ($item -is [array] -and $item.count -eq 0) { '@()' }
	else { $item }
}

function Constrain($item)
{
	$text = [string]$item # convert non-strings to string for handling as characters
	if ($text.length -gt $displayLenMax)
	{ $text = $text.substring(0,$displayLenMax - $ellipsis.length - 1) + $ellipsis }
	return ($exprOpen + $text + $exprClose)
}

Export-ModuleMember Assert-Expression
Export-ModuleMember Set-AbortOnError
Export-ModuleMember Set-MaxExpressionDisplayLength
Export-ModuleMember Get-AssertCounts

