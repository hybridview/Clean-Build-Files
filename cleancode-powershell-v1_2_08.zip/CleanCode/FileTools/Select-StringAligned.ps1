﻿#
# ==============================================================
# @ID       $Id: Select-StringAligned.ps1 1492 2014-03-19 16:20:27Z ms $
# @created  2011-07-01
# @project  http://cleancode.sourceforge.net/
# ==============================================================
#
# The official license for this file is shown next.
# Unofficially, consider this e-postcardware as well:
# if you find this module useful, let us know via e-mail, along with
# where in the world you are and (if applicable) your website address.
#
#
# ***** BEGIN LICENSE BLOCK *****
# Version: MPL 1.1
#
# The contents of this file are subject to the Mozilla Public License Version
# 1.1 (the "License"); you may not use this file except in compliance with
# the License. You may obtain a copy of the License at
# http://www.mozilla.org/MPL/
#
# Software distributed under the License is distributed on an "AS IS" basis,
# WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
# for the specific language governing rights and limitations under the
# License.
#
# The Original Code is part of the CleanCode toolbox.
#
# The Initial Developer of the Original Code is Michael Sorens.
# Portions created by the Initial Developer are Copyright (C) 2011
# the Initial Developer. All Rights Reserved.
#
# Contributor(s):
#
# ***** END LICENSE BLOCK *****
#

Set-StrictMode -Version Latest

<#

.SYNOPSIS
Finds text in strings and files and makes the output aligned rather than ragged based on file name lengths.

.DESCRIPTION

The Select-StringAligned cmdlet searches for text and text patterns in input strings and files similar to its counterpart, Select-String.  It differs in two main features: It aligns the lines of matched text (by putting the file name and line number in fixed width fields) and it highlights the matched text.

Compare this output from Select-StringAligned:

    Assertion\Assertion.Tests.ps1           : 17: # the Mozilla License Version
    FileTools\ConvertFrom-Text.ps1          : 17: # the Mozilla License Version
    FileTools\ConvertFrom-Text.Tests.ps1    : 17: # the Mozilla License Version
    FileTools\FileTree.ps1                  : 17: # the Mozilla License Version

with this output from Select-String:

    Assertion\Assertion.Tests.ps1:17:# the Mozilla License Version
    FileTools\ConvertFrom-Text.ps1:17:# the Mozilla License Version
    FileTools\ConvertFrom-Text.Tests.ps1:17:# the Mozilla License Version
    FileTools\FileTree.ps1:17:# the Mozilla License Version

Select-StringAligned is line-oriented. By default, it highlights all matches in each line and, for each line displays the file name, line number, and text of the line with each match highlighted.  Select-StringAligned uses regular expression matching.

Select-StringAligned implements some of Select-String's options allowing you to display lines before and after each matched line, or display just the first match in each file.  It also has several custom parameters allowing you to adjust the fixed width of the file name field and the line number field.

Highlighting is one of the two main benefits of Select-StringAligned.  However, be aware that highlighted output is not pipelineable!  You may, however, send the aligned output into a pipeline--without the highlight--with the -PassThru option.

Another enhancement of Select-StringAligned is that it reports relative paths whenever possible whereas Select-String always reports absolute paths, making output lines always lengthy. Thus, instead of
    C:\Users\me\some\lengthy\pass\here\that\just\goes\on\and\on\file.cs: 132 ...
you might see
    .\file.cs: 132 ...
or
    ..\..\..\and\on\file.cs: 132 ...
(Note that it is rather unwieldy to go up more than three levels (..\..\..), though, so it will revert to absolute paths at that point.)

If you do a lot of searching, it is convenient to have a helper alias with the options you prefer.  Here is an example that you might put in your PowerShell profile named after the common Unix/Linux grep:

    function grep($txtpat, $filepat="*") {
        Get-ChildItem . -Exclude *.exe,*.obj,*.suo,*.user -Include $filepat -File -Recurse |
        Select-StringAligned $txtpat -NameWidth 40 -Context 2,3
    }

What I use is very similar, except that I use my own extension to Get-ChildItem that allows pruning whole trees:
    Get-EnhancedChildItem . -ExcludeTree .svn,bin,obj -exclude *.exe,*.obj,*.suo,*.user ...

Get-EnhancedChildItem is also available in this CleanCode library.

.PARAMETER Path
Specifies the path to the files to be searched. Wildcards are permitted.
The default location is the local directory.

Specify files in the directory, such as "log1.txt", "*.doc", or "*.*".
If you specify only a directory, the command fails.

.PARAMETER Pattern
Specifies the text to find as a regular expression.
To learn about regular expressions, see about_Regular_Expressions.

.PARAMETER Context
Captures the specified number of lines before and after the line with the match.
This allows you to view the match in context.

If you enter one number as the value of this parameter, that number determines
the number of lines captured before and after the match. If you enter two numbers
as the value, the first number determines the number of lines before the match
and the second number determines the number of lines after the match.

In the default display, the actual matched lines have the search target
highlighted. Unmarked lines are the context.

.PARAMETER NameWidth
Specifies the fixed width of the file name portion of the output.

.PARAMETER NumberWidth
Specifies the fixed width of the line number portion of the output.

.PARAMETER CaseSensitive
Makes matches case-sensitive. By default, matches are not case-sensitive.

.PARAMETER List
Returns only the first match in each input file.
By default, all matches are reported.

.PARAMETER PassThru
Sends the output to stdout rather than the PowerShell host console.
This allows the output to be piped to another command
but also disables match highlighting as a consequence.

.INPUTS
You can pipe any object that has a ToString method to Select-String.

.OUTPUTS
Array of System.String objects (with -PassThru) or none (default).

.EXAMPLE
PS> Select-StringAligned -Path *.ps1 -Pattern ^function
Search ps1 files in the current directory only and find lines beginning with "function".
Example output:
    SvnInfo.ps1                        :  193: function Get-SvnInfo(
    SvnInfo.ps1                        :  239: function Match-Expression($string, $regex)
    SvnInfo.ps1                        :  248: function ConvertTo-HashTable()
    SvnInfo.Tests.ps1                  :   44: function Get-PropertyCount($results)
    SvnKeywords.ps1                    :  222: function Measure-SvnKeywords(
    SvnKeywords.ps1                    :  318: function Progress($activity)
    SvnKeywords.ps1                    :  324: function GetExtensionsEnabledInConfig()

.EXAMPLE
PS> Get-ChildItem -Recurse *.ps1 | Select-StringAligned -Pattern ^function
Search ps1 files in the current directory and its descendants and find lines beginning with "function".
Example output:
    SqlTools\DefaultContext.ps1        :  249: function Invoke-InferredSqlcmd()
    SqlTools\Out-DataTable.ps1         :   62: function Out-DataTable
    SqlTools\Out-DataTable.ps1         :  136: function Get-Type
    SqlTools\Out-SqlTable.ps1          :  154: function Out-SqlTable
    SqlTools\Write-DataTable.ps1       :  104: function Write-DataTable
    SvnTools\SvnInfo.ps1               :  193: function Get-SvnInfo(
    SvnTools\SvnInfo.ps1               :  239: function Match-Expression($string, $regex)
    SvnTools\SvnInfo.ps1               :  248: function ConvertTo-HashTable()
    SvnTools\SvnInfo.Tests.ps1         :   44: function Get-PropertyCount($results)
    SvnTools\SvnKeywords.ps1           :  222: function Measure-SvnKeywords(
    SvnTools\SvnKeywords.ps1           :  318: function Progress($activity)
    SvnTools\SvnKeywords.ps1           :  324: function GetExtensionsEnabledInConfig()


.EXAMPLE
PS> Get-ChildItem -Recurse | Select-StringAligned '<summary>' -Context 0,1
Search all files in the tree rooted at the current directory, find instances of "<summary>" documentation tags and print both that line and one line immediately following it. Note that as soon as the context widens the viewport to more than one line, you also get "---" separators between matches.
Example output:
    Forms\WindowRestorer.cs    :  341:         /// <summary>
    Forms\WindowRestorer.cs    :  342:         /// Sets the location of a sub-window relative to its base form
    ---
    Forms\WindowRestorer.cs    :  358:         /// <summary>
    Forms\WindowRestorer.cs    :  359:         /// Maximizes a form over multiple monitors.
    ---
    IO\Comparators.cs          :   48:      /// <summary>
    IO\Comparators.cs          :   49:      /// An <see cref="IComparer"/> for sorting files by ascending date.
    ---
    IO\Comparators.cs          :   69:              /// <summary>
    IO\Comparators.cs          :   70:              /// Compares two <see cref="FileSystemInfo"/> objects
    ---
    IO\Comparators.cs          :  103:      /// <summary>
    IO\Comparators.cs          :  104:      /// An <see cref="IComparer"/> for sorting files by descending date.
    ---

.EXAMPLE
PS> Get-ChildItem -Recurse | Select-StringAligned -Pattern '<summary>' -Context 0,1 -PassThru | Select-String -Pattern '<summary>','---' -NotMatch
Search all files in the tree rooted at the current directory, find instances of "<summary>" documentation tags and include the line immediately following it, then filter that again to report only that line immediately following. That is, filter out the "<summary>" match anchor and the "---" occurrence separators. Note that in order to pipe the output of Select-StringAligned you must include the -PassThru parameter. That makes the output pipelineable (with the side effect of losing the color-coding).

Example output:
    Forms\WindowRestorer.cs    :  342:         /// Sets the location of a sub-window relative to its base form
    Forms\WindowRestorer.cs    :  359:         /// Maximizes a form over multiple monitors.
    IO\Comparators.cs          :   49:      /// An <see cref="IComparer"/> for sorting files by ascending date.
    IO\Comparators.cs          :   70:              /// Compares two <see cref="FileSystemInfo"/> objects
    IO\Comparators.cs          :  104:      /// An <see cref="IComparer"/> for sorting files by descending date.

.NOTES
This function is part of the CleanCode toolbox
from http://cleancode.sourceforge.net/.

Since CleanCode 1.2.03.

.LINK
Select-String

#>

function Select-StringAligned
{
    [CmdletBinding()]
    Param (
    [Parameter(Mandatory=$true,Position=1, ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true)]
	[SupportsWildcards()]
    [object[]]$Path,

    [Parameter(Mandatory=$true,Position=0)]
    [string]$Pattern,

    [int[]]$Context   = @(0),
    [int]$NameWidth   = 35,
    [int]$NumberWidth = 5,
    [switch]$CaseSensitive,
    [switch]$List,
    [switch]$PassThru
    )

    BEGIN {
        $firstTime = $true
        $pwd.Path -match "(^[A-Z]+:\\[^\\]*)" | Out-Null
        $script:pwdTop = $Matches[0] 
    }

    PROCESS {
        $groupSeparator = "---"
        select-string -Path $Path -Pattern $Pattern -Context $Context -CaseSensitive:$CaseSensitive -List:$List |
        % {
            $entry = $_            
    
            $offset = & {
                if ($Context[0] -eq 0) { 0 }
                else { @($entry.Context.PreContext).Count }
            }
    
            $linenum = $entry.LineNumber - $offset
            if ((ContextRequested) -and -not $firstTime) { Write-Output $groupSeparator }
            $firstTime = $false
    
            Get-Lines $entry | % {
                $prefix = Get-Prefix $entry ($linenum++)
                if ($PassThru) { Write-Output "$prefix$_" }
                else {
                    Write-Host $prefix -NoNewline
                    if ($entry.LineNumber+1 -eq $linenum) {
                        Colorize-Tokens $_ $Pattern
                    }
                    else { Write-Host $_ }
                }
            }
        }
    }
}

function ContextRequested()
{
    return ($Context[0] -gt 0 -or ($Context.Count -gt 1 -and $Context[1] -gt 0))
}

function Get-TruncatedName($entry)
{
    $entry.Path -match "(^[A-Z]+:\\[^\\]+)" | Out-Null
    $entryTop = $Matches[0] 
    $relativePath = & {
        if ($entryTop -eq $pwdTop)
        { Resolve-Path -relative $entry.Path } # common root; OK to use relative path
        else { $entry.Path } # disparate root; use absolute path
    }
    # revert to absolute if too many ".." occurrences!
    if ($relativePath -match "^(?:..\\){4}") { $relativePath = $entry.Path }
    
    $truncatedName = & {
        if ($relativePath.length -lt $nameWidth) { $relativePath }
        else { $relativePath.SubString(0,$NameWidth) }
    }
    return $truncatedName
}

function Get-Prefix($entry, $linenum)
{
    "{0,-$NameWidth}:{1,$NumberWidth}: " -f (Get-TruncatedName $entry), $linenum
}

function Get-Lines($entry)
{
    # For some reason need to special case the $list construction; otherwise acts like Context=(1,1)
    if (-not (ContextRequested)) {
        $list = $entry.Line
    }
    else {
        $list =  @($entry.Context.PreContext)
        $list += $entry.Line
        $list += $entry.Context.PostContext
    }
    $list
}

function Colorize-Tokens($line, $regex)
{
    $options = & {
        if ($CaseSensitive) { [System.Text.RegularExpressions.RegexOptions]::None } 
        else { [System.Text.RegularExpressions.RegexOptions]::IgnoreCase }
    }
    [regex]::matches($line, $regex, $options) |
    % {
       $curMatch = $_.Value
       $curMatchPos = $line.IndexOf($curMatch)
       Write-Host -NoNewline $line.Substring(0, $curMatchPos)
       Write-Host -NoNewline $line.Substring($curMatchPos, $curMatch.Length) -ForegroundColor Green
       $line = $line.Substring($curMatchPos + $curMatch.Length)
    }    
    Write-Host $line # output remainder
}

Export-ModuleMember Select-StringAligned
