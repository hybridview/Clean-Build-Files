﻿function Export-Excel([string]$FilePath, [string]$Title, [string]$Author, [string]$SheetName, [Object[]]$Data)
{
    # Specify to save in a standard .XSLX format.
    $xlOpenXMLType = 51 # SEE: http://msdn.microsoft.com/en-us/library/bb241279.aspx

    $csvFile = Join-Path $env:temp ("{0}.csv" -f ([System.IO.FileInfo]$FilePath).BaseName)
    if (Test-Path -path $csvFile) { Remove-Item -path $csvFile }
    if (Test-Path -path $FilePath) { Remove-Item -path $FilePath }

    $Data | Export-Csv -path $csvFile -noTypeInformation
 
    $excelObject = New-Object -comObject Excel.Application
    $excelObject.Visible = $false 
    $workbookObject = $excelObject.Workbooks.Open($csvFile)
    $workbookObject.Title = $Title
    $workbookObject.Author = $Author
    $worksheetObject = $workbookObject.Worksheets.Item(1)
    $worksheetObject.UsedRange.Columns.Autofit() | Out-Null
    $worksheetObject.Name = $SheetName
    $workbookObject.SaveAs($FilePath, $xlOpenXMLType)
    $workbookObject.Saved = $true
    $workbookObject.Close()

    # cleanup
    if (Test-Path -path $csvFile) { Remove-Item -path $csvFile }
    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($workbookObject) | Out-Null
    $excelObject.Quit()
    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($excelObject) | Out-Null
    [System.GC]::Collect()
    [System.GC]::WaitForPendingFinalizers()
}

# Export-Excel "C:\usr\tmp\sample-out.xlsx" "wkbk title" "ms" "my sheet" (Get-Process)